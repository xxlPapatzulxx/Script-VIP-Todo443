from xdxl import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline(" 𝗠𝗘𝗡𝗨 ","menu")],
[Button.url("𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠","https://t.me/Jerry_SBG"),
Button.url("𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣","https://wa.me/+529241293310")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨", alert=True)
		except:
			await event.reply("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨")
	elif val == "true":
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		name = f" cat /usr/bin/user"
		user = subprocess.check_output(name, shell=True).decode("ascii")
		seller = f" cat /usr/bin/seller"
		user2= subprocess.check_output(seller, shell=True).decode("ascii")
		svf = f" cat /root/ipbot | cut -d ' ' -f4"
		tg= subprocess.check_output(svf, shell=True).decode("ascii")	
		expi = f" cat /root/ipbot | cut -d ' ' -f3"
		exp= subprocess.check_output(expi, shell=True).decode("ascii")	
		msg = f"""
━━━━━━━━━━━━━━━━━━━
🅱🅾🆃 🅶🅴🅽 🅺🅴🆈🆂 🅿🆁🅴🅼🅸🆄🅼
━━━━━━━━━━━━━━━━━━━
 🔰 » 𝕊.𝕆      : `{namaos.strip().replace('"','')}`
━━━━━━━━━━━━━━━━━━━
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼𝕃 𝔹𝕆𝕋  : ✅
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼 𝕃𝔸 𝔹.𝔻 : ✅
━━━━━━━━━━━━━━━━━━━
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™         
━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
