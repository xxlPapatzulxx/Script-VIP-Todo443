from xdxl import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline(" 𝗠𝗘𝗡𝗨 ","menu")],
[Button.url("𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠","https://t.me/Jerry_SBG"),
Button.url("𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣","https://wa.me/+529241293310")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Acceso Denegado", alert=True)
		except:
			await event.reply("Acceso Denegado")
	elif val == "true":
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		date = f" cat /root/ipbot | sed ':a;' | cut -d ' ' -f3 "
		key = subprocess.check_output(date, shell=True).decode("ascii")
		msg = f"""
**✧◇━━━━━━━━━━━━━━━◇✧**
🅱🅾🆃 🅶🅴🅽 🅺🅴🆈🆂 🅿🆁🅴🅼🅸🆄🅼
**✧◇━━━━━━━━━━━━━━━◇✧**
     **✨ 𝐇𝐎𝐋𝐀 {sender.username} **
     **✨ 𝐈𝐃 𝐓𝐆: {sender.id} **
     **✨ 𝐄𝐗𝐏𝐈𝐑𝐀: {key.strip().replace('"','')} **
**✧◇━━━━━━━━━━━━━━━◇✧**
 🔰 » 𝕊.𝕆      : `{namaos.strip().replace('"','')}`
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼𝕃 𝔹𝕆𝕋  : ✅
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼 𝕃𝔸 𝔹.𝔻 : ✅
**✧◇━━━━━━━━━━━━━━━◇✧**
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™         
            ᴅᴜᴅᴀꜱ ᴀ 🤖@Jerry_SBG
✧◇━━━━━━━━━━━━━━━◇✧
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
