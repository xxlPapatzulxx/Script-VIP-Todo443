from xdxl import *

@bot.on(events.CallbackQuery(data=b'normal'))
async def keys(event):
    async def keys_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
━━━━━━━━━━━━━━━━━
    𝕂𝔼𝕐 𝔻𝔼 𝔸ℂℂ𝔼𝕊𝕆 𝔻𝔼𝕃 𝔾𝔼ℕ
━━━━━━━━━━━━━━━━━
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ᴋᴇʏ ᴘᴇʀꜱᴏɴᴀʟ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝗜𝗡𝗚𝗥𝗘𝗦𝗔 𝗧𝗨 𝗞𝗘𝗬 𝗗𝗘 𝗔𝗖𝗖𝗘𝗦𝗢  :**
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            cmd = f'printf "{user}" | bash add-ip | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
**» ℙ𝔸ℕ𝔼𝕃 𝕄𝔼ℕ𝕌**
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys_(event)
    else:
        await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'normal2'))
async def keys2(event):
    async def keys2_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
━━━━━━━━━━━━━━━━━
    𝕂𝔼𝕐 𝔻𝔼 𝔸ℂℂ𝔼𝕊𝕆 𝔻𝔼𝕃 𝔾𝔼ℕ
━━━━━━━━━━━━━━━━━
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ᴋᴇʏ ᴘᴇʀꜱᴏɴᴀʟ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝗜𝗡𝗚𝗥𝗘𝗦𝗔 𝗧𝗨 𝗞𝗘𝗬 𝗗𝗘 𝗔𝗖𝗖𝗘𝗦𝗢  :**
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            cmd = f'printf "{user}" | bash add-ip2 | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
**» ℙ𝔸ℕ𝔼𝕃 𝕄𝔼ℕ𝕌**
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys2_(event)
    else:
        await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'normal3'))
async def keys3(event):
    async def keys3_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
━━━━━━━━━━━━━━━━━
    𝕂𝔼𝕐 𝔻𝔼 𝔸ℂℂ𝔼𝕊𝕆 𝔻𝔼𝕃 𝔾𝔼ℕ
━━━━━━━━━━━━━━━━━
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ᴋᴇʏ ᴘᴇʀꜱᴏɴᴀʟ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝗜𝗡𝗚𝗥𝗘𝗦𝗔 𝗧𝗨 𝗞𝗘𝗬 𝗗𝗘 𝗔𝗖𝗖𝗘𝗦𝗢  :**
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            cmd = f'printf "{user}" | bash add-ip3 | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
**» ℙ𝔸ℕ𝔼𝕃 𝕄𝔼ℕ𝕌**
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys3_(event)
    else:
        await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'vip'))
async def vip(event):
    async def vip_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
━━━━━━━━━━━━━━━━━
    𝕂𝔼𝕐 𝔻𝔼 𝔸ℂℂ𝔼𝕊𝕆 𝔻𝔼𝕃 𝔾𝔼ℕ
━━━━━━━━━━━━━━━━━
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ᴋᴇʏ ᴘᴇʀꜱᴏɴᴀʟ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝗜𝗡𝗚𝗥𝗘𝗦𝗔 𝗧𝗨 𝗞𝗘𝗬 𝗗𝗘 𝗔𝗖𝗖𝗘𝗦𝗢  :**
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            cmd = f'printf "{user}" | bash add-ip4 | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
**» ℙ𝔸ℕ𝔼𝕃 𝕄𝔼ℕ𝕌**
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vip_(event)
    else:
        await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'registrasi'))
async def vless(event):
    async def vless_(event):
        inline = [
[Button.inline(" ‹ 𝗖𝗥𝗘𝗔𝗥 𝗞𝗘𝗬 𝟳 𝗗𝗜𝗔𝗦 ›","normal")],
[Button.inline(" ‹ 𝗖𝗥𝗘𝗔𝗥 𝗞𝗘𝗬 𝟭𝟱 𝗗𝗜𝗔𝗦 ›","normal2")],
[Button.inline(" ‹ 𝗖𝗥𝗘𝗔𝗥 𝗞𝗘𝗬 𝟯𝟬 𝗗𝗜𝗔𝗦 ›","normal3")],
[Button.inline(" ‹ 𝗙𝗘𝗖𝗛𝗔 𝗗𝗘𝗟 𝗩𝗘𝗡𝗗𝗘𝗗𝗢𝗥 ›","vip")],
[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]]
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        name = f" cat /usr/bin/user"
        user = subprocess.check_output(name, shell=True).decode("ascii")
        seller = f" cat /usr/bin/seller"
        user2= subprocess.check_output(seller, shell=True).decode("ascii")
        svf = f" cat /root/ipbot | cut -d ' ' -f4"
        tg= subprocess.check_output(svf, shell=True).decode("ascii")      
        expi = f" cat /root/ipbot | cut -d ' ' -f3"
        exp= subprocess.check_output(expi, shell=True).decode("ascii")  
        msg = f"""
━━━━━━━━━━━━━━━━━━━
🅱🅾🆃 🅶🅴🅽 🅺🅴🆈🆂 🅿🆁🅴🅼🅸🆄🅼
━━━━━━━━━━━━━━━━━━━
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼𝕃 𝔹𝕆𝕋  : ✅
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼 𝕃𝔸 𝔹.𝔻 : ✅
━━━━━━━━━━━━━━━━━━━
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™   
            ᴅᴜᴅᴀꜱ ᴀ 🤖@Jerry_SBG    
━━━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vless_(event)
    else:
        await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)
