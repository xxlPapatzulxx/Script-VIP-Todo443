from xdxl import *

@bot.on(events.CallbackQuery(data=b'normal'))
async def keys(event):
    async def keys_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
━━━━━━━━━━━━━━━━━
    𝕂𝔼𝕐 𝔻𝔼 𝔸ℂℂ𝔼𝕊𝕆 𝔻𝔼𝕃 𝔾𝔼ℕ
━━━━━━━━━━━━━━━━━
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ᴋᴇʏ ᴘᴇʀꜱᴏɴᴀʟ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝗜𝗡𝗚𝗥𝗘𝗦𝗔 𝗧𝗨 𝗞𝗘𝗬 𝗗𝗘 𝗔𝗖𝗖𝗘𝗦𝗢  :**
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            cmd = f'printf "{user}" | bash add-ip | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
**» ℙ𝔸ℕ𝔼𝕃 𝕄𝔼ℕ𝕌**
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys_(event)
    else:
        await event.answer("Acesso Denegado",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'normal2'))
async def keys2(event):
    async def keys2_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
━━━━━━━━━━━━━━━━━
    𝕂𝔼𝕐 𝔻𝔼 𝔸ℂℂ𝔼𝕊𝕆 𝔻𝔼𝕃 𝔾𝔼ℕ
━━━━━━━━━━━━━━━━━
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ᴋᴇʏ ᴘᴇʀꜱᴏɴᴀʟ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝗜𝗡𝗚𝗥𝗘𝗦𝗔 𝗧𝗨 𝗞𝗘𝗬 𝗗𝗘 𝗔𝗖𝗖𝗘𝗦𝗢  :**
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            cmd = f'printf "{user}" | bash add-ip2 | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
**» ℙ𝔸ℕ𝔼𝕃 𝕄𝔼ℕ𝕌**
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys2_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'normal3'))
async def vip(event):
    async def vip_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
━━━━━━━━━━━━━━━━━
    𝕂𝔼𝕐 𝔻𝔼 𝔸ℂℂ𝔼𝕊𝕆 𝔻𝔼𝕃 𝔾𝔼ℕ
━━━━━━━━━━━━━━━━━
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ᴋᴇʏ ᴘᴇʀꜱᴏɴᴀʟ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝗜𝗡𝗚𝗥𝗘𝗦𝗔 𝗧𝗨 𝗞𝗘𝗬 𝗗𝗘 𝗔𝗖𝗖𝗘𝗦𝗢  :**
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            cmd = f'printf "{user}" | bash add-ip3 | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
**» ℙ𝔸ℕ𝔼𝕃 𝕄𝔼ℕ𝕌**
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vip_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'vip'))
async def keys3(event):
    async def keys3_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
━━━━━━━━━━━━━━━━━
    𝕂𝔼𝕐 𝔻𝔼 𝔸ℂℂ𝔼𝕊𝕆 𝔻𝔼𝕃 𝔾𝔼ℕ
━━━━━━━━━━━━━━━━━
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ᴋᴇʏ ᴘᴇʀꜱᴏɴᴀʟ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝗜𝗡𝗚𝗥𝗘𝗦𝗔 𝗧𝗨 𝗞𝗘𝗬 𝗗𝗘 𝗔𝗖𝗖𝗘𝗦𝗢  :**
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond(f"""
**✨ 𝐃𝐈𝐀𝐒 𝐃𝐄 𝐄𝐗𝐏𝐈𝐑𝐀𝐂𝐈𝐎𝐍  :**
""")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        async with bot.conversation(chat) as op:
            await event.respond(f"""
━━━━━━━━━━━━━━━━━
    𝐌𝐄𝐍𝐔 𝐊𝐄𝐘 𝐄𝐍 𝐕𝐏𝐒
━━━━━━━━━━━━━━━━━
**✨ 𝕋𝕆𝔻𝕆 𝔼ℕ 𝕄𝔸𝕐𝕌𝕊ℂ𝕌𝕃𝔸 **
**✨ ᴘᴏᴅᴇʀ ɢᴇɴᴇʀᴀʀ ᴅᴇꜱᴅᴇ ᴇʟ **
**✨ ᴀᴜᴛᴏꜱᴄʀɪᴘᴛ ᴅᴇ ᴛᴜ ᴠᴘꜱ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐔𝐍𝐀 𝐎𝐏𝐂. 𝐎𝐍/𝐎𝐅𝐅  :**
""")
            op = op.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            op = (await op).raw_text
        async with bot.conversation(chat) as ox:
            await event.respond(f"""
━━━━━━━━━━━━━━━━━
    𝐈𝐍𝐒𝐓𝐀𝐋𝐀𝐃𝐎𝐑 𝐃𝐄 𝐁𝐎𝐓
━━━━━━━━━━━━━━━━━
**✨ 𝕋𝕆𝔻𝕆 𝔼ℕ 𝕄𝔸𝕐𝕌𝕊ℂ𝕌𝕃𝔸 **
**✨ ᴘᴏᴅᴇʀ ɪɴꜱᴛᴀʟᴀʀ ᴛᴜ ᴘʀᴏᴘɪᴀ **
**✨ ʙᴀꜱᴇ ᴅᴇ ᴅᴀᴛᴏꜱ ᴄᴏɴ ɢᴇɴ ʙᴏᴛ**
**✨ ᴅᴜᴅᴀꜱ ᴀ : @Jerry_SBG**
━━━━━━━━━━━━━━━━━
**✨ 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐔𝐍𝐀 𝐎𝐏𝐂. 𝐕𝐈𝐏/𝐎𝐅𝐅  :**
""")
            ox = ox.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ox = (await ox).raw_text
            cmd = f'printf "%s\n" "{user}" "{exp}" "{op}" "{ox}"| bash add-ip4 | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"""
**» ℙ𝔸ℕ𝔼𝕃 𝕄𝔼ℕ𝕌**
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys3_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'registrasi'))
async def vless(event):
    async def vless_(event):
        inline = [
[Button.inline(" ‹ 𝗖𝗥𝗘𝗔𝗥 𝗞𝗘𝗬 𝟯𝟬 𝗗𝗜𝗔𝗦 ›","normal")],
[Button.inline(" ‹ 𝗖𝗥𝗘𝗔𝗥 𝗞𝗘𝗬 𝟔𝟎 𝗗𝗜𝗔𝗦 ›","normal2")],
[Button.inline(" ‹ 𝗙𝗘𝗖𝗛𝗔 𝗗𝗘𝗟 𝗩𝗘𝗡𝗗𝗘𝗗𝗢𝗥 ›","normal3")],
[Button.inline(" ‹ 𝐃𝐈𝐀𝐒 𝐏𝐄𝐑𝐒𝐎𝐍𝐀𝐋𝐈𝐙𝐀𝐃𝐎𝐒 ›","vip")],
[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]]
        date = f" cat /root/ipbot | sed ':a;' | cut -d ' ' -f3 "
        date2 = subprocess.check_output(date, shell=True).decode("ascii")
        key = f" cat /root/ipbot | sed ':a;' | cut -d ' ' -f7 "
        key2 = subprocess.check_output(key, shell=True).decode("ascii")
        msg = f"""
**✧◇━━━━━━━━━━━━━━━◇✧**
🅱🅾🆃 🅶🅴🅽 🅺🅴🆈🆂 🅿🆁🅴🅼🅸🆄🅼
**✧◇━━━━━━━━━━━━━━━◇✧**
     **✨ 𝐇𝐎𝐋𝐀 {sender.username} **
     **✨ 𝐈𝐃 𝐓𝐆: {sender.id} **
     **✨ 𝐄𝐗𝐏𝐈𝐑𝐀: {date2.strip().replace('"','')} **
**✧◇━━━━━━━━━━━━━━━◇✧**
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼𝕃 𝔹𝕆𝕋  : ✅
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼 𝕃𝔸 𝔹.𝔻 : ✅
**✧◇━━━━━━━━━━━━━━━◇✧**
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™   
            ᴅᴜᴅᴀꜱ ᴀ 🤖@Jerry_SBG
**✧◇━━━━━━━━━━━━━━━◇✧**
      ✨ 🅺🅴🆈 🅲🅾🅿🅸🅰🅻🅰 ✨
           **{key2.strip().replace('"','')} **
✧◇━━━━━━━━━━━━━━━◇✧
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vless_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
