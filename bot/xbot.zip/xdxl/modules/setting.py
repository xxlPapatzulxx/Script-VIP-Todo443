from xdxl import *

@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
	async def resx_(event):
		cmd = f'bash resservice'
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
» ʀᴇɪɴɪᴄɪᴀᴅᴏ ʙᴏᴛ ᴅᴇ ᴋᴇʏ
━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™  
     🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await resx_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)
		
@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline(" ‹ 𝗥𝗘𝗜𝗡𝗜𝗖𝗜𝗔𝗥 𝗕𝗢𝗧 ›","resx"),
Button.inline(" ‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]]
		msg = f"""
━━━━━━━━━━━━━━━━━━━
🅱🅾🆃 🅶🅴🅽 🅺🅴🆈🆂 🅿🆁🅴🅼🅸🆄🅼
━━━━━━━━━━━━━━━━━━━
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼𝕃 𝔹𝕆𝕋  : ✅
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼 𝕃𝔸 𝔹.𝔻 : ✅
━━━━━━━━━━━━━━━━━━━
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™   
            ᴅᴜᴅᴀꜱ ᴀ 🤖@Jerry_SBG  
━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)
