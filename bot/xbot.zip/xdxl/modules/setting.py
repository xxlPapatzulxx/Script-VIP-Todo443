from xdxl import *

@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
	async def resx_(event):
		cmd = f'systemctl restart sbgbot'
		subprocess.check_output(cmd, shell=True)
		await event.edit("ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ.")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 50%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 80%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit(f"""
» ʀᴇɪɴɪᴄɪᴀᴅᴏ ʙᴏᴛ ᴋᴇʏ
━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™  
     🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await resx_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
	async def info_vps_(event):
		cmd = f"systemctl status sbgbot | grep 'Active' |  cut -d ' ' -f 7 | nl -s ') '".strip()
		await event.edit("ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ.")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`ᴇꜱᴘᴇʀᴇ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴅᴀᴛᴏꜱ ᴅᴇʟ ꜱᴇʀᴠɪᴅᴏʀ`")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
𝐄𝐒𝐓𝐀𝐃𝐎 𝐃𝐄𝐋 𝐁𝐎𝐓
{z}
**🤖@𝐉𝐞𝐫𝐫𝐲_𝐒𝐁𝐆**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await info_vps_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline(" ‹ 𝗥𝗘𝗜𝗡𝗜𝗖𝗜𝗔𝗥 𝗕𝗢𝗧 ›","resx"),
Button.inline(" ‹ 𝐈𝐍𝐅𝐎 𝐁𝐎𝐓 ›","info")],
[Button.inline(" ‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]]
		date = f" cat /root/ipbot | sed ':a;' | cut -d ' ' -f3 "
		key = subprocess.check_output(date, shell=True).decode("ascii")
		msg = f"""
**✧◇━━━━━━━━━━━━━━━◇✧**
🅱🅾🆃 🅶🅴🅽 🅺🅴🆈🆂 🅿🆁🅴🅼🅸🆄🅼
**✧◇━━━━━━━━━━━━━━━◇✧**
     **✨ 𝐇𝐎𝐋𝐀 {sender.username} **
     **✨ 𝐈𝐃 𝐓𝐆: {sender.id} **
     **✨ 𝐄𝐗𝐏𝐈𝐑𝐀: {key.strip().replace('"','')} **
**✧◇━━━━━━━━━━━━━━━◇✧**
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼𝕃 𝔹𝕆𝕋  : ✅
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼 𝕃𝔸 𝔹.𝔻 : ✅
**✧◇━━━━━━━━━━━━━━━◇✧**
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™   
            ᴅᴜᴅᴀꜱ ᴀ 🤖@Jerry_SBG  
✧◇━━━━━━━━━━━━━━━◇✧
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("Access Denied",alert=True)
