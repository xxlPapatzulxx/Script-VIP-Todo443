from xdxl import *

@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
	async def resx_(event):
		cmd = f'systemctl restart sbgbot'
		subprocess.check_output(cmd, shell=True)
		await event.edit("Procesando.")
		time.sleep(1)
		await event.edit("`Procesando Informacion del Servidor...`")
		time.sleep(2)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 50%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 80%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit(f"""
» ʀᴇɪɴɪᴄɪᴀᴅᴏ ʙᴏᴛ ᴋᴇʏ
━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™  
     🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await resx_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)
		
@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline(" ‹ 𝗥𝗘𝗜𝗡𝗜𝗖𝗜𝗔𝗥 𝗕𝗢𝗧 ›","resx"),
Button.inline(" ‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]]
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		msg = f"""
━━━━━━━━━━━━━━━━━━━
🅱🅾🆃 🅶🅴🅽 🅺🅴🆈🆂 🅿🆁🅴🅼🅸🆄🅼
━━━━━━━━━━━━━━━━━━━
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼𝕃 𝔹𝕆𝕋  : ✅
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼 𝕃𝔸 𝔹.𝔻 : ✅
━━━━━━━━━━━━━━━━━━━
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™   
            ᴅᴜᴅᴀꜱ ᴀ 🤖@Jerry_SBG  
━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("Access Denied",alert=True)
