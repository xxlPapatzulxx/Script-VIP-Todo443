from xdxl import *

@bot.on(events.CallbackQuery(data=b'domain'))
async def perpanjang(event):
    async def perpanjang_(event):
        chat = event.chat_id  # Ambil ID obrolan dari objek event
        async with bot.conversation(chat) as exp:
            await event.respond("    𝗘𝗹𝗶𝗴𝗲 𝗧𝘂 𝗗𝗼𝗺𝗶𝗻𝗶𝗼 𝗚𝗿𝗮𝘁𝗶𝘀 ", buttons=[
                [Button.inline(" ᴍʏᴘʀᴇᴍɪᴜᴍ.ʙɪᴢ.ɪᴅ ", "1"),
                 Button.inline(" ᴋʟᴍᴘᴋ.ᴍᴇ ", "2")],
                [Button.inline(" ᴋʟᴍᴘᴋ.ᴍʏ.ɪᴅ ", "3"),
                Button.inline(" ᴠɪᴘᴍᴇ.ᴍʏ.ɪᴅ ", "4")],
                [Button.inline(" ᴋʟᴍᴘᴋ-ᴛᴜɴɴᴇʟɪɴɢ.ᴍʏ.ɪᴅ ", "5"),
                Button.inline(" ᴠᴘɴ-ꜱᴛᴏʀᴇ.ᴍʏ.ɪᴅ ", "6")],
                [Button.inline(" ᴋʟᴍᴘᴋ.ᴄꜰᴅ ", "7"),
                 Button.inline(" ꜱᴇʀᴠᴇʀ-ᴛᴜɴɴᴇʟɪɴɢ.ᴛᴇᴄʜ ", "8")]            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        async with bot.conversation(chat) as user:
            await event.respond('    𝗜𝗻𝗴𝗿𝗲𝘀𝗲 𝘂𝗻 𝗡𝗼𝗺𝗯𝗿𝗲 𝗽𝗮𝗿𝗮 𝗲𝗹 𝗦𝘂𝗯𝗱𝗼𝗺𝗶𝗻𝗶𝗼:')
            #await event.respond('**Ejempo: testvpsvip O soyelkingsbg**')
            user = user.wait_event(events.NewMessage(incoming=True))
            user = (await user).raw_text
        async with bot.conversation(chat) as pw:
            await event.respond("    𝐈𝐧𝐠𝐫𝐞𝐬𝐞 𝐥𝐚 𝐈𝐏 𝐝𝐞𝐥 𝐕𝐏𝐒:")
            pw = pw.wait_event(events.NewMessage(incoming=True))
            pw = (await pw).raw_text            
        
        cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" | domain'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"Error: {e}")
        else:
            msg = f"""```{a}```
**✧◇━━━━━━━━━━━━━━━◇✧**
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™   
                     🤖@Jerry_SBG   
✧◇━━━━━━━━━━━━━━━◇✧
"""
            await event.respond(msg)

    # Tidak perlu pengecekan validitas, langsung jalankan fungsi
    await perpanjang_(event)
