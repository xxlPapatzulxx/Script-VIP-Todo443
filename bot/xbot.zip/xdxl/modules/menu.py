from xdxl import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [  
[Button.inline(" ‹ 𝗖𝗢𝗡𝗙𝗜𝗚𝗨𝗥𝗔𝗖𝗜𝗢𝗡𝗘𝗦 ›","setting")],
[Button.inline(" ‹ 𝗗𝗢𝗠𝗜𝗡𝗜𝗢𝗦 𝗙𝗥𝗘𝗘 ›","domain")],
[Button.inline(" ‹ 𝗚𝗘𝗡𝗘𝗥𝗔𝗥 𝗞𝗘𝗬𝗦 ›","registrasi")],
[Button.inline(" ‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨", alert=True)
		except:
			await event.reply("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨")
	elif val == "true":
		msg = f"""
━━━━━━━━━━━━━━━━━━━
🅱🅾🆃 🅶🅴🅽 🅺🅴🆈🆂 🅿🆁🅴🅼🅸🆄🅼
━━━━━━━━━━━━━━━━━━━
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼𝕃 𝔹𝕆𝕋  : ✅
 🔰 » 𝔼𝕊𝕋𝔸𝔻𝕆 𝔻𝔼 𝕃𝔸 𝔹.𝔻 : ✅
━━━━━━━━━━━━━━━━━━━
            ᴄᴏᴍᴘʀᴀ ᴛᴜ ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
            ᴄʀᴇᴀᴅᴏʀ 🅑🅨🅙🅔🅡🅡🅨™   
            ᴅᴜᴅᴀꜱ ᴀ 🤖@Jerry_SBG   
━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
