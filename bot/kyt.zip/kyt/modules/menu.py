from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" 𝗠𝗘𝗡𝗨 𝗦𝗦𝗛","ssh")],
[Button.inline(" 𝗠𝗘𝗡𝗨 𝗩𝗠𝗘𝗦𝗦","vmess"),
Button.inline(" 𝗠𝗘𝗡𝗨 𝗩𝗟𝗘𝗦𝗦","vless")],
[Button.inline(" 𝗠𝗘𝗡𝗨 𝗧𝗥𝗢𝗝𝗔𝗡","trojan"),
Button.inline(" 𝗠𝗘𝗡𝗨 𝗦𝗛𝗗𝗪𝗦𝗞","shadowsocks")],
[Button.inline(" 𝗖𝗛𝗘𝗖𝗞 𝗦𝗘𝗥𝗩𝗜𝗖𝗘","info"),
Button.inline(" 𝗢𝗧𝗛𝗘𝗥 𝗦𝗘𝗧𝗧𝗜𝗡𝗚","setting")],
[Button.inline(" ‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Acceso Denegado", alert=True)
		except:
			await event.reply("Acceso Denegado")
	elif val == "true":
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipinfo.io/ip"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
━━━━━━━━━━━━━━━━━━━
**🔹🅿🆁🅴🅼🅸🆄🅼 🅿🅰🅽🅴🅻 🅼🅴🅽🆄🔹
━━━━━━━━━━━━━━━━━━━
**🔰 » 𝕊.𝕆      : `{namaos.strip().replace('"','')}`
**🔰 » ℂ𝕀𝕌𝔻𝔸𝔻  : `{city.strip()}`
**🔰 » 𝔻𝕆𝕄𝕀ℕ𝕀𝕆 : `{DOMAIN}`
**🔰 » 𝕀ℙ 𝕍ℙ𝕊 : `{ipsaya.strip()}`
» ᴛᴏᴛᴀʟ ᴄᴜᴇɴᴛᴀꜱ ᴄʀᴇᴀᴅᴀꜱ :

**» 🟢ꜱꜱʜ ᴏᴠᴘɴ    : `{ssh.strip()}` __account__
**» 🟢xʀᴀʏ ᴠᴍᴇꜱꜱ  : `{vms.strip()}` __account__
**» 🟢xʀᴀʏ ᴠʟᴇꜱꜱ  : `{vls.strip()}` __account__
**» 🟢xʀᴀʏ ᴛʀᴏᴊᴀɴ : `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━
**🅲🆁🅴🅰🅳🅾🆁 🅑🅨 🅙🅔🅡🅡🅨™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
