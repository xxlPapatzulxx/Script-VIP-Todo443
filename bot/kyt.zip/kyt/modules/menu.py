from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" 𝓒𝓞𝓝𝓕𝓘𝓖𝓤𝓡𝓐𝓒𝓘𝓞𝓝𝓔𝓢","setting")],
[Button.inline(" 𝓓𝓞𝓜𝓘𝓝𝓘𝓞𝓢 𝓕𝓡𝓔𝓔","domain")],
[Button.inline(" 𝓖𝓔𝓝𝓔𝓡𝓐𝓓𝓞𝓡 𝓚𝓔𝓨","registrasi")],
[Button.inline(" ‹ 𝓡𝓔𝓖𝓡𝓔𝓢𝓐𝓡› ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Acceso Denegado", alert=True)
		except:
			await event.reply("Acceso Denegado")
	elif val == "true":
		ssdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		name = f" cat /usr/bin/user"
		user = subprocess.check_output(name, shell=True).decode("ascii")
		seller = f" cat /usr/bin/seller"
		user2= subprocess.check_output(seller, shell=True).decode("ascii")
		svf = f" cat /usr/bin/kyt/var.txt | grep -w ADMIN | head -n1 | sed 's/=//g' | sed 's/ADMIN//g'"
		tg= subprocess.check_output(svf, shell=True).decode("ascii")	
		msg = f"""
━━━━━━━━━━━━━━━━━━━
🅿🆁🅴🅼🅸🆄🅼 🅿🅰🅽🅴🅻 🅼🅴🅽🆄
━━━━━━━━━━━━━━━━━━━
**🔰 » ꜱ.ᴏ      : `{namaos.strip().replace('"','')}`
**🔰 » ᴅᴏᴍɪɴɪᴏ : `{DOMAIN}`
**🔰 » ɪᴘ ᴠᴘꜱ  : `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━
**🔰 » ɪᴅ ᴛɢ  : `{tg.strip()}` <<<
**🔰 » ᴠᴇɴᴅᴇᴅᴏʀ : `{user2.strip()}`
━━━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™   
    🤖@Jerry_SBG     
━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
