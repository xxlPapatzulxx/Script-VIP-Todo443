from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" 𝐌𝐄𝐍𝐔 𝐒𝐒𝐇 ","ssh"),
Button.inline(" 𝐌𝐄𝐍𝐔 𝐕𝐌𝐄𝐒𝐒 ","vmess")],
[Button.inline(" 𝐌𝐄𝐍𝐔 𝐕𝐋𝐄𝐒𝐒 ","vless"),
Button.inline(" 𝐌𝐄𝐍𝐔 𝐓𝐑𝐎𝐉𝐀𝐍 ","trojan")],
[Button.inline(" 𝐍𝐎𝐎𝐁𝐙𝐕𝐏𝐍𝐒 𝐎𝐅𝐅 ","noobz"),
Button.inline(" 𝐓𝐑𝐎𝐉𝐀𝐍-𝐆𝐎 ","trojan-go")],
[Button.inline(" 𝐕𝐏𝐒 𝐈𝐍𝐅𝐎 ","info"),
Button.inline(" 𝐒𝐄𝐓𝐓𝐈𝐍𝐆 ","setting")],
[Button.inline(" ‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎", alert=True)
		except:
			await event.reply("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎")
	elif val == "true":
		sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/xray/config.json | grep "#vmg" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/xray/config.json | grep "#vlg" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/xray/config.json | grep "#trg" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		noob = f' cat /etc/xray/noob | grep "###" | wc -l'
		noobz = subprocess.check_output(noob, shell=True).decode("ascii")
		tgo = f' cat /etc/trojan-go/trgo | grep "###" | wc -l'
		trgo = subprocess.check_output(tgo, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
**✧◇━━━━━━━━━━━━━━━◇✧**
**🔥 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 🔥**
**✧◇━━━━━━━━━━━━━━━◇✧**

**» ℍ𝕆𝕃𝔸 {sender.first_name} **

**»✨ 𝐒.𝐎    :** `{namaos.strip().replace('"','')}`
**»✨ 𝐂𝐈𝐔𝐃𝐀𝐃 :** `{city.strip()}`
**»✨ 𝐃𝐎𝐌𝐈𝐍𝐈𝐎:** `{DOMAIN}`
**»✨ 𝐈𝐏 𝐕𝐏𝐒  :** `{ipsaya.strip()}`
**✧◇━━━━━━━━━━━━━━━◇✧**
            **💥⟨ 𝐓𝐎𝐓𝐀𝐋 𝐂𝐔𝐄𝐍𝐓𝐀𝐒 ⟩💥**
**✧◇━━━━━━━━━━━━━━━◇✧**
**»✨ 𝐒𝐒𝐇 𝐎𝐕𝐏𝐍   :** `{ssh.strip()}` __CUENTAS__
**»✨ 𝐗𝐑𝐀𝐘 𝐕𝐌𝐄𝐒𝐒 :** `{vms.strip()}` __CUENTAS__
**»✨ 𝐗𝐑𝐀𝐘 𝐕𝐋𝐄𝐒𝐒  :** `{vls.strip()}` __CUENTAS__
**»✨ 𝐗𝐑𝐀𝐘 𝐓𝐑𝐎𝐉𝐀𝐍 :** `{trj.strip()}` __CUENTAS__
**»✨ 𝐍𝐎𝐎𝐁𝐙𝐕𝐏𝐍𝐒  :** `{noobz.strip()}` __CUENTAS__
**»✨ 𝐓𝐑𝐎𝐉𝐀𝐍-𝐆𝐎  :** `{trgo.strip()}` __CUENTAS__
**»🤖 @𝐉𝐞𝐫𝐫𝐲_𝐒𝐁𝐆**
**✧◇━━━━━━━━━━━━━━━◇✧**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
