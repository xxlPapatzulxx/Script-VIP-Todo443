from kyt import *
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'proto'))
async def info_vps(event):
	async def info_vps_(event):
		cmd = 'bot-vps-info'.strip()
		await event.edit("ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ.")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ ɪɴꜰᴏ ᴀʟ ꜱᴇʀᴠɪᴅᴏʀ...`")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 100%\n█████████████████████████ `")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
𝐄𝐒𝐓𝐀𝐃𝐎 𝐃𝐄𝐋 𝐁𝐎𝐓
{z}
**🤖» https://t.me/Jerry_SBG**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await info_vps_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)


@bot.on(events.CallbackQuery(data=b'info2'))
async def info_vps(event):
	async def info_vps_(event):
		cmd = f"systemctl status kyt | grep 'Active' |  cut -d ' ' -f 7 | nl -s ')'".strip()
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ ɪɴꜰᴏ ᴀʟ ꜱᴇʀᴠɪᴅᴏʀ...`")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 100%\n█████████████████████████ `")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
𝐄𝐒𝐓𝐀𝐃𝐎 𝐃𝐄𝐋 𝐁𝐎𝐓
{z}
**🤖» https://t.me/Jerry_SBG**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await info_vps_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)



@bot.on(events.CallbackQuery(data=b'info'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline(" 𝐒𝐄𝐑𝐕𝐈𝐂𝐈𝐎𝐒 𝐎𝐍","proto"),
Button.inline(" 𝐁𝐎𝐓 𝐕𝐏𝐒","info2")],
[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**✧◇━━━━━━━━━━━━━━◇✧**
**🔥 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 🔥**
**✧◇━━━━━━━━━━━━━━◇✧**
🔱 **» 𝐃𝐎𝐌𝐈𝐍𝐈𝐎:** `{DOMAIN}`
🔱 **» 𝐈𝐒𝐏:** `{z["isp"]}`
🔱 **» 𝐂𝐈𝐔𝐃𝐀𝐃:** `{z["country"]}`
🤖 **» https://t.me/Jerry_SBG**
**✧◇━━━━━━━━━━━━━━◇✧**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
