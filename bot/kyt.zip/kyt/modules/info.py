from kyt import *
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
	async def info_vps_(event):
		cmd = 'systemctl status kyt'.strip()
		await event.edit("ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ.")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ ɪɴꜰᴏ ᴀʟ ꜱᴇʀᴠɪᴅᴏʀ...`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`ᴇꜱᴘᴇʀᴇ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴅᴀᴛᴏꜱ ᴅᴇʟ ꜱᴇʀᴠɪᴅᴏʀ`")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
**🤖@𝐉𝐞𝐫𝐫𝐲_𝐒𝐁𝐆**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await info_vps_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
