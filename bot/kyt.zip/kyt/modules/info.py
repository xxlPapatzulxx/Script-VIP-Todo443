from kyt import *
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
	async def info_vps_(event):
		cmd = 'bot-vps-info'.strip()
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ...ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴅᴀᴛᴏꜱ ᴅᴇʟ ꜱᴇʀᴠɪᴅᴏʀ`")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
🤖@Jerry_SBG
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await info_vps_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)
