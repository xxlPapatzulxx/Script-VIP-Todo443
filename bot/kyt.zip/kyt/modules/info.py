from kyt import *
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
	async def info_vps_(event):
		cmd = 'bot-vps-info'.strip()
		await event.edit("Procesando.")
		await event.edit("Procesando..")
		await event.edit("Procesando...")
		await event.edit("Procesando....")
		time.sleep(3)
		await event.edit("`Procesando Info al Servidor...`")
		time.sleep(1)
		await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(3)
		await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Procesando... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Espere... Configurando datos del Servidor`")
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
**🤖@Jerry_SBG**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await info_vps_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
