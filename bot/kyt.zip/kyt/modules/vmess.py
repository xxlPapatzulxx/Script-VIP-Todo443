from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐋𝐈𝐒𝐓𝐀 𝐄𝐋𝐈𝐌𝐈𝐍𝐀𝐑 𝐔𝐒𝐔𝐀𝐑𝐈𝐎**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-vmess'))
async def renew_vmess(event):
	async def renew_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐑𝐄𝐍𝐎𝐕𝐀𝐂𝐈𝐎𝐍 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 𝐍𝐔𝐄𝐕𝐀 𝐄𝐗𝐏 (𝐃𝐈𝐀𝐒) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)


#limit
@bot.on(events.CallbackQuery(data=b'limit7-vmess'))
async def limit_vmess(event):
	async def limit_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐂𝐀𝐌𝐁𝐈𝐀𝐑 𝐋𝐈𝐌𝐈𝐓𝐄 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 𝐄𝐬𝐜𝐫𝐢𝐛𝐚 𝐍𝐮𝐞𝐯𝐨 𝐥í𝐦𝐢𝐭𝐞 𝐝𝐞 𝐈𝐏 :**
0 𝐏𝐀𝐑𝐀 𝐈𝐋𝐈𝐌𝐈𝐓𝐀𝐃𝐎
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**👉 𝐄𝐬𝐜𝐫𝐢𝐛𝐚 𝐍𝐮𝐞𝐯𝐨 𝐥í𝐦𝐢𝐭𝐞 𝐝𝐞 𝐂𝐮𝐨𝐭𝐚 :**
0 𝐏𝐀𝐑𝐀 𝐈𝐋𝐈𝐌𝐈𝐓𝐀𝐃𝐎
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			cmd = f'printf "%s\n" "7" "{user}" "{exp}" "{pw}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

#CekConfig
@bot.on(events.CallbackQuery(data=b'akun7-vmess'))
async def akun_vmess(event):
	async def akun_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐂𝐎𝐍𝐅𝐈𝐆 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
		
#restore
@bot.on(events.CallbackQuery(data=b'restore7-vmess'))
async def restore_vmess(event):
	async def restore_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/akundelete | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐑𝐄𝐒𝐓𝐀𝐔𝐑𝐀𝐂𝐈𝐎𝐍 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 𝐍𝐔𝐄𝐕𝐀 𝐄𝐗𝐏 (𝐃𝐈𝐀𝐒) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**👉 𝐍𝐔𝐄𝐕𝐎 𝐋𝐈𝐌𝐈𝐓𝐄 𝐈𝐏 𝐋𝐎𝐆𝐈𝐍 :**
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**👉 𝐍𝐔𝐄𝐕𝐀 𝐂𝐔𝐎𝐓𝐀 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎 :**
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "11" "{user}" "{exp}" "{pw}" "{pw2}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐒𝐓𝐎****
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await restore_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)


#MultiLogin Login
@bot.on(events.CallbackQuery(data=b'loginip7-vmess'))
async def loginip_vmess(event):
	async def loginip_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/listlock | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒 𝐌𝐔𝐋𝐓𝐈 𝐋𝐎𝐆𝐈𝐍**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐃𝐄𝐒𝐁𝐋𝐎𝐐𝐔𝐄𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await loginip_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
#MultiLogin Quota
@bot.on(events.CallbackQuery(data=b'logingb7-vmess'))
async def logingb_vmess(event):
	async def logingb_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/userQuota | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐂𝐔𝐎𝐓𝐀 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "10" "{user}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐃𝐄𝐒𝐁𝐋𝐎𝐐𝐔𝐄𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await logingb_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.edit(f"""
**✨ ɴᴏᴍʙʀᴇ ᴍɪxᴛᴏ, ʟᴇᴛʀᴀꜱ ᴍᴀʏÚꜱᴄᴜʟᴀꜱ ʏ ɴÚᴍᴇʀᴏꜱ**
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ꜱɪɴ ᴅᴏʙʟᴇ ɴᴏᴍʙʀᴇ**
**✨ Bot : @Jerry_SBG**

**👉 𝐍𝐎𝐌𝐁𝐑𝐄 𝐃𝐄 𝐂𝐔𝐄𝐍𝐓𝐀  :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐀 𝐄𝐗𝐏 (𝐃𝐈𝐀𝐒) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**👉 𝐋𝐈𝐌𝐈𝐓𝐄 𝐈𝐍𝐈𝐂𝐈𝐎 𝐃𝐄 𝐒𝐄𝐒𝐈𝐎𝐍 :**
0 𝐏𝐀𝐑𝐀 𝐈𝐋𝐈𝐌𝐈𝐓𝐀𝐃𝐎
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**👉 𝐋𝐈𝐌𝐈𝐓𝐄 𝐂𝐔𝐎𝐓𝐀 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎 :**
0 𝐏𝐀𝐑𝐀 𝐈𝐋𝐈𝐌𝐈𝐓𝐀𝐃𝐎
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{pw}" "{pw2}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐂𝐑𝐄𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
**👉 𝐈𝐍𝐆𝐑𝐄𝐒𝐀 𝐋𝐀 𝐄𝐗𝐏 (𝐌𝐈𝐍𝐔𝐓𝐎𝐒) :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | bash m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True).decode("utf-8")
			await event.respond(f"""
**» 𝐂𝐑𝐄𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 100%\n█████████████████████████ `")
		await event.edit(f"""
**✨ 𝐕𝐌𝐄𝐒𝐒 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒 𝐎𝐍𝐋𝐈𝐍𝐄**
{z}
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'login7-vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" 𝐔𝐍𝐋𝐎𝐂𝐊 𝐋𝐎𝐆𝐈𝐍 ","loginip7-vmess"),
Button.inline(" 𝐔𝐍𝐋𝐎𝐂𝐊 𝐂𝐔𝐎𝐓𝐀 ","logingb7-vmess")],
[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","vmess")]]
		await event.edit(buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" 𝐓𝐑𝐈𝐀𝐋 ","trial7-vmess"),
Button.inline(" 𝐂𝐑𝐄𝐀𝐑 ","create7-vmess"),
Button.inline(" 𝐀𝐂𝐓𝐈𝐕𝐎𝐒 ","cek7-vmess")],
[Button.inline(" 𝐁𝐎𝐑𝐑𝐀𝐑 ","delete7-vmess"),
Button.inline(" 𝐔𝐍𝐋𝐎𝐂𝐊 ","login7-vmess"),
Button.inline(" 𝐋𝐈𝐌𝐈𝐓𝐄 ","limit7-vmess")],
[Button.inline(" 𝐑𝐄𝐍𝐎𝐕𝐀𝐑","renew7-vmess"),
Button.inline(" 𝐑𝐄𝐒𝐓𝐀𝐔𝐑𝐀𝐑 ","restore7-vmess"),
Button.inline(" 𝐂𝐔𝐄𝐍𝐓𝐀 ","akun7-vmess")],
[Button.inline("‹ REGRESAR ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vm = f' cat /etc/xray/config.json | grep "#vmg" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		msg = f"""
**✧◇━━━━━━━━━━━━━━━◇✧**
      **🔥 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 🔥**
**✧◇━━━━━━━━━━━━━━━◇✧**
✨ **» 𝐏𝐑𝐎𝐓𝐎𝐂𝐎𝐋𝐎:** `𝕍𝕄𝔼𝕊𝕊`
✨ **» 𝐓𝐎𝐓𝐀𝐋 𝐂𝐔𝐄𝐍𝐓𝐀𝐒  :** `{vms.strip()}` __CUENTAS__
✨ **» 𝐃𝐎𝐌𝐈𝐍𝐈𝐎:** `{DOMAIN}`
✨ **» 𝐂𝐈𝐔𝐃𝐀𝐃:** `{z["city"]}`
✨ **» 𝐏𝐀𝐈𝐒:** `{z["country"]}`
🤖 **» @𝐉𝐞𝐫𝐫𝐲_𝐒𝐁𝐆**
**✧◇━━━━━━━━━━━━━━━◇✧**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
