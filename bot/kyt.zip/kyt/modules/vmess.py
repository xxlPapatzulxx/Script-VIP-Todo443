from kyt import *

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'crear-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ɴᴏᴍʙʀᴇ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**ʟɪᴍɪᴛᴇ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**",buttons=[
[Button.inline(" 1 ᴜꜱᴜᴀʀɪᴏ ","1"),
Button.inline(" 2 ᴜꜱᴜᴀʀɪᴏꜱ ","2")],
[Button.inline(" 3 ᴜꜱᴜᴀʀɪᴏꜱ ","3"),
Button.inline(" 4 ᴜꜱᴜᴀʀɪᴏꜱ ","4")],
[Button.inline(" 5 ᴜꜱᴜᴀʀɪᴏꜱ ","5"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","1000")]])
			pw = pw.wait_event(events.CallbackQuery)
			pw = (await pw).data.decode("ascii")
		async with bot.conversation(chat) as pw2:
			await event.respond("**ʟɪᴍɪᴛᴇ ᴄᴜᴏᴛᴀ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**",buttons=[
[Button.inline(" 1 ɢʙ ","1"),
Button.inline(" 15 ɢʙ ","15")],
[Button.inline(" 150 ɢʙ ","150"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","3000")]])
			pw2 = pw2.wait_event(events.CallbackQuery)
			pw2 = (await pw2).data.decode("ascii")	
		async with bot.conversation(chat) as exp:
			await event.respond('**ᴅɪᴀꜱ ᴅᴇ ᴇxᴘɪʀᴀᴄɪóɴ:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴜɴᴀ ᴄᴜᴇɴᴛᴀ`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{uuid}" "{pw}" "{pw2}" | addws-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 𝕐𝕒 𝔼𝕩𝕚𝕤𝕥𝕖**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
#			c = [x.group() for x in re.finditer("Host XrayDNS(.*)",a)]
#			d = [x.group() for x in re.finditer("Pub Key(.*)",a)]
			print(b)
#			print(d)
#			print(c)
#			xx = re.search("Pub Key      :(.*)",d[0]).group(1)
#			xxx = re.search("Host XrayDNS :(.*)",d[0]).group(1)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🆇🆁🅰🆈/🆅🅼🅴🆂🆂 🅰🅲🅲🅾🆄🅽🆃
◇━━━━━━━━━━━━━━━━━◇
» Usuario      : `{z["ps"]}`
» Domain       : `{z["add"]}`
» XRAY DNS     : `{HOST}`
» Limit IP     : `{pw} IP`
» User Cuota   : `{pw2} GB`
» Port DNS     : `443, 53`
» port TLS     : `443`
» Port NTLS    : `80`
» Port GRPC    : `443`
» User ID      : `{z["id"]}`
» AlterId      : `0`
» Security     : `auto`
» NetWork      : `(WS) or (gRPC)`
» Path TLS     : `(/multi path)/vmess`
» Path NLS     : `(/multi path)/vmess`
» Path Dynamic : `http://google.com`
» ServiceName  : `vmess-grpc`
» Pub Key      : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS     :
`{b[0].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS    :
`{b[1].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC    :
`{b[2].strip("'")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : https://{DOMAIN}:81/vmess-{user}.txt
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

#CRATE VMESS ID
@bot.on(events.CallbackQuery(data=b'id-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ɴᴏᴍʙʀᴇ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as uuid:
			await event.respond('**ɪᴅ ᴏ ᴘʀᴇꜱɪᴏɴᴀ ᴇɴᴛᴇʀ ᴘᴀʀᴀ ᴜɴ ᴀʟᴇᴛᴏʀɪᴏ:**')
			uuid = uuid.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			uuid = (await uuid).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**ʟɪᴍɪᴛᴇ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**",buttons=[
[Button.inline(" 1 ᴜꜱᴜᴀʀɪᴏ ","1"),
Button.inline(" 2 ᴜꜱᴜᴀʀɪᴏꜱ ","2")],
[Button.inline(" 3 ᴜꜱᴜᴀʀɪᴏꜱ ","3"),
Button.inline(" 4 ᴜꜱᴜᴀʀɪᴏꜱ ","4")],
[Button.inline(" 5 ᴜꜱᴜᴀʀɪᴏꜱ ","5"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","1000")]])
			pw = pw.wait_event(events.CallbackQuery)
			pw = (await pw).data.decode("ascii")
		async with bot.conversation(chat) as pw2:
			await event.respond("**ʟɪᴍɪᴛᴇ ᴄᴜᴏᴛᴀ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**",buttons=[
[Button.inline(" 1 ɢʙ ","1"),
Button.inline(" 15 ɢʙ ","15")],
[Button.inline(" 150 ɢʙ ","150"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","3000")]])
			pw2 = pw2.wait_event(events.CallbackQuery)
			pw2 = (await pw2).data.decode("ascii")	
		async with bot.conversation(chat) as exp:
			await event.respond('**ᴅɪᴀꜱ ᴅᴇ ᴇxᴘɪʀᴀᴄɪóɴ:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴜɴᴀ ᴄᴜᴇɴᴛᴀ`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{uuid}" "{pw}" "{pw2}" | addwsid-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 𝕐𝕒 𝔼𝕩𝕚𝕤𝕥𝕖**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
#			c = [x.group() for x in re.finditer("Host XrayDNS(.*)",a)]
#			d = [x.group() for x in re.finditer("Pub Key(.*)",a)]
			print(b)
#			print(d)
#			print(c)
#			xx = re.search("Pub Key      :(.*)",d[0]).group(1)
#			xxx = re.search("Host XrayDNS :(.*)",d[0]).group(1)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🆇🆁🅰🆈/🆅🅼🅴🆂🆂 🅰🅲🅲🅾🆄🅽🆃
◇━━━━━━━━━━━━━━━━━◇
» Usuario      : `{z["ps"]}`
» Domain       : `{z["add"]}`
» XRAY DNS     : `{HOST}`
» Limit IP     : `{pw} IP`
» User Cuota   : `{pw2} GB`
» Port DNS     : `443, 53`
» port TLS     : `443`
» Port NTLS    : `80`
» Port GRPC    : `443`
» User ID      : `{z["id"]}`
» AlterId      : `0`
» Security     : `auto`
» NetWork      : `(WS) or (gRPC)`
» Path TLS     : `(/multi path)/vmess`
» Path NLS     : `(/multi path)/vmess`
» Path Dynamic : `http://BUG.COM`
» ServiceName  : `vmess-grpc`
» Pub Key      : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS     :
`{b[0].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS    :
`{b[1].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC    :
`{b[2].strip("'")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : https://{DOMAIN}:81/vmess-{user}.txt
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

# CUENTA TEMPORAL VMESS
@bot.on(events.CallbackQuery(data=b'temporal-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**ᴇꜱᴄᴏɢᴇʀ ᴍɪɴᴜᴛᴏꜱ ᴅᴇ ᴇxᴘɪʀᴀᴄɪóɴ**",buttons=[
[Button.inline(" 10 ᴍɪɴᴜᴛᴏꜱ ","10"),
Button.inline(" 15 ᴍɪɴᴜᴛᴏꜱ ","15")],
[Button.inline(" 30 ᴍɪɴᴜᴛᴏꜱ ","30"),
Button.inline(" 60 ᴍɪɴᴜᴛᴏꜱ ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(3)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴜɴᴀ ᴄᴜᴇɴᴛᴀ`")
		cmd = f'printf "%s\n" "{exp}" | bot-trialws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 𝕐𝕒 𝔼𝕩𝕚𝕤𝕥𝕖**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🆇🆁🅰🆈/🆅🅼🅴🆂🆂 🅰🅲🅲🅾🆄🅽🆃
◇━━━━━━━━━━━━━━━━━◇
» Usuario      : `{z["ps"]}`
» Domain       : `{z["add"]}`
» XRAY DNS     : `{HOST}`
» User Cuota   : `1`
» Limit IP     : `3`
» Port DNS     : `443, 53`
» port TLS     : `443`
» Port NTLS    : `80`
» Port GRPC    : `443`
» User ID      : `{z["id"]}`
» AlterId      : `0`
» Security     : `auto`
» NetWork      : `(WS) or (gRPC)`
» Path TLS     : `(/multi path)/vmess`
» Path NLS     : `(/multi path)/vmess`
» Path Dynamic : `http://BUG.COM`
» ServiceName  : `vmess-grpc`
» Pub Key      : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS     :
`{b[0].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS    :
`{b[1].strip("'").replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC    :
`{b[2].strip("'")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : https://{DOMAIN}:81/vmess-{z["ps"]}.txt
◇━━━━━━━━━━━━━━━━━━━◇
» Expira En: `{exp} Minutos`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

#CHECAR USUARIOS VMESS
@bot.on(events.CallbackQuery(data=b'checar-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
Usuarios Vmess Registrados
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

@bot.on(events.CallbackQuery(data=b'borrar-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-delws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 ℕ𝕠 𝔼𝕟𝕔𝕠𝕟𝕥𝕣𝕒𝕕𝕠**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			msg = f"""**𝔹𝕠𝕣𝕣𝕒𝕕𝕠 𝔼𝕩𝕚𝕥𝕠𝕤𝕒𝕞𝕖𝕟𝕥𝕖**"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" 𝗧𝗥𝗜𝗔𝗟 𝗩𝗠𝗘𝗦𝗦 ","temporal-vmess")],
[Button.inline(" 𝗖𝗥𝗘𝗔𝗥 𝗩𝗠𝗘𝗦𝗦 ","crear-vmess"),
Button.inline(" 𝗖𝗥𝗘𝗔𝗥 𝗩𝗠𝗘𝗦𝗦 𝗜𝗗","id-vless")],
[Button.inline(" 𝗖𝗛𝗘𝗖𝗞 𝗩𝗠𝗘𝗦𝗦 ","checar-vmess"),
Button.inline(" 𝗕𝗢𝗥𝗥𝗔𝗥 𝗩𝗠𝗘𝗦𝗦 ","borrar-vmess")],
[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━
**🔹🆅🅼🅴🆂🆂 🅼🅰🅽🅰🅶🅴🆁🔹
━━━━━━━━━━━━━━━━━━━
**🔰 » 𝕊𝕖𝕣𝕧𝕚𝕔𝕖: `VMESS`
**🔰 » 𝔻𝕠𝕞𝕚𝕟𝕚𝕠/𝕀ℙ: `{DOMAIN}`
**🔰 » 𝕀𝕊ℙ: `{z["isp"]}`
**🔰 » ℂ𝕠𝕦𝕟𝕥𝕣𝕪: `{z["country"]}`
━━━━━━━━━━━━━━━━━━━
**🅲🆁🅴🅰🅳🅾🆁 🅑🅨 🅙🅔🅡🅡🅨™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)
