from kyt import *

@bot.on(events.CallbackQuery(data=b'crear-vless'))
async def create_vless(event):
	async def create_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ɴᴏᴍʙʀᴇ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**ʟɪᴍɪᴛᴇ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**",buttons=[
[Button.inline(" 1 ᴜꜱᴜᴀʀɪᴏ ","1"),
Button.inline(" 2 ᴜꜱᴜᴀʀɪᴏꜱ ","2")],
[Button.inline(" 3 ᴜꜱᴜᴀʀɪᴏꜱ ","3"),
Button.inline(" 4 ᴜꜱᴜᴀʀɪᴏꜱ ","4")],
[Button.inline(" 5 ᴜꜱᴜᴀʀɪᴏꜱ ","5"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","1000")]])
			pw = pw.wait_event(events.CallbackQuery)
			pw = (await pw).data.decode("ascii")
		async with bot.conversation(chat) as pw2:
			await event.respond("**ʟɪᴍɪᴛᴇ ᴄᴜᴏᴛᴀ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**",buttons=[
[Button.inline(" 1 ɢʙ ","1"),
Button.inline(" 15 ɢʙ ","15")],
[Button.inline(" 150 ɢʙ ","150"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","3000")]])
			pw2 = pw2.wait_event(events.CallbackQuery)
			pw2 = (await pw2).data.decode("ascii")
		async with bot.conversation(chat) as exp:
			await event.respond('**ᴅɪᴀꜱ ᴅᴇ ᴇxᴘɪʀᴀᴄɪóɴ:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴜɴᴀ ᴄᴜᴇɴᴛᴀ`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{pw2}"| addvless-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 𝕐𝕒 𝔼𝕩𝕚𝕤𝕥𝕖**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🆇🆁🅰🆈/🆅🅻🅴🆂🆂 🅰🅲🅲🅾🆄🅽🆃
◇━━━━━━━━━━━━━━━━━◇
» Usuario     : `{user}`
» Host Server : `{DOMAIN}`
» Host XrayDNS: `{HOST}`
» User Limit  : `{pw} IP`
» User Cuota  : `{pw2} GB`
» Port DNS    : `443, 53`
» port TLS    : `443`
» Port NTLS   : `80`
» NetWork     : `(WS) or (gRPC)`
» User ID     : `{uuid}`
» Path Vless  : `(/multi path)/vless `
» Path Dynamic: `http://google.com/vless `
» Pub Key     : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS  :
`{x[0]}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS :
`{x[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC :
`{x[2].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : https://{DOMAIN}:81/vless-{user}.txt
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vless_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

@bot.on(events.CallbackQuery(data=b'id-vless'))
async def create_vless(event):
	async def create_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ɴᴏᴍʙʀᴇ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as uuid:
			await event.respond('**ɪᴅ ᴏ ᴘʀᴇꜱɪᴏɴᴀ ᴇɴᴛᴇʀ ᴘᴀʀᴀ ᴜɴ ᴀʟᴇᴛᴏʀɪᴏ:**')
			uuid = uuid.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			uuid = (await uuid).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**ʟɪᴍɪᴛᴇ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**",buttons=[
[Button.inline(" 1 ᴜꜱᴜᴀʀɪᴏ ","1"),
Button.inline(" 2 ᴜꜱᴜᴀʀɪᴏꜱ ","2")],
[Button.inline(" 3 ᴜꜱᴜᴀʀɪᴏꜱ ","3"),
Button.inline(" 4 ᴜꜱᴜᴀʀɪᴏꜱ ","4")],
[Button.inline(" 5 ᴜꜱᴜᴀʀɪᴏꜱ ","5"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","1000")]])
			pw = pw.wait_event(events.CallbackQuery)
			pw = (await pw).data.decode("ascii")
		async with bot.conversation(chat) as pw2:
			await event.respond("**ʟɪᴍɪᴛᴇ ᴄᴜᴏᴛᴀ ᴅᴇ ᴜꜱᴜᴀʀɪᴏ:**",buttons=[
[Button.inline(" 1 ɢʙ ","1"),
Button.inline(" 15 ɢʙ ","15")],
[Button.inline(" 150 ɢʙ ","150"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","3000")]])
			pw2 = pw2.wait_event(events.CallbackQuery)
			pw2 = (await pw2).data.decode("ascii")
		async with bot.conversation(chat) as exp:
			await event.respond('**ᴅɪᴀꜱ ᴅᴇ ᴇxᴘɪʀᴀᴄɪóɴ:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴜɴᴀ ᴄᴜᴇɴᴛᴀ`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{uuid}" "{pw}" "{pw2}"| addvlessid-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 𝕐𝕒 𝔼𝕩𝕚𝕤𝕥𝕖**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🆇🆁🅰🆈/🆅🅻🅴🆂🆂 🅰🅲🅲🅾🆄🅽🆃
◇━━━━━━━━━━━━━━━━━◇
» Usuario     : `{user}`
» Host Server : `{DOMAIN}`
» Host XrayDNS: `{HOST}`
» User Limit  : `{pw} IP`
» User Cuota  : `{pw2} GB`
» Port DNS    : `443, 53`
» port TLS    : `443`
» Port NTLS   : `80`
» NetWork     : `(WS) or (gRPC)`
» User ID     : `{uuid}`
» Path Vless  : `(/multi path)/vless `
» Path Dynamic: `http://Google.com/vless `
» Pub Key     : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS  :
`{x[0]}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS :
`{x[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC :
`{x[2].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Format OpenClash : https://{DOMAIN}:81/vless-{user}.txt
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vless_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

#Checar Usuarios
@bot.on(events.CallbackQuery(data=b'checar-vless'))
async def cek_vless(event):
	async def cek_vless_(event):
		cmd = 'bot-cek-vless'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
Usuarios Vless Registrados
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vless_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

#Borrar Usuarios
@bot.on(events.CallbackQuery(data=b'borrar-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ᴜꜱᴜᴀʀɪᴏ:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-delvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 ℕ𝕠 𝔼𝕟𝕔𝕠𝕟𝕥𝕣𝕒𝕕𝕠**")
		else:
			msg = f"""**𝔹𝕠𝕣𝕣𝕒𝕕𝕠 𝔼𝕩𝕚𝕥𝕠𝕤𝕒𝕞𝕖𝕟𝕥𝕖**"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

#Crear Cuenta Temporal
@bot.on(events.CallbackQuery(data=b'temporal-vless'))
async def trial_vless(event):
	async def trial_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**ᴇꜱᴄᴏɢᴇʀ ᴍɪɴᴜᴛᴏꜱ ᴅᴇ ᴇxᴘɪʀᴀᴄɪóɴ**",buttons=[
[Button.inline(" 10 ᴍɪɴᴜᴛᴏꜱ ","10"),
Button.inline(" 15 ᴍɪɴᴜᴛᴏꜱ ","15")],
[Button.inline(" 30 ᴍɪɴᴜᴛᴏꜱ ","30"),
Button.inline(" 60 ᴍɪɴᴜᴛᴏꜱ ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴜɴᴀ ᴄᴜᴇɴᴛᴀ`")
		cmd = f'printf "%s\n" "{exp}" | bot-trialvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 𝕐𝕒 𝔼𝕩𝕚𝕤𝕥𝕖**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🆇🆁🅰🆈/🆅🅻🅴🆂🆂 🅰🅲🅲🅾🆄🅽🆃
◇━━━━━━━━━━━━━━━━━◇
» Usuario     : `{remarks}`
» Host Server : `{DOMAIN}`
» Host XrayDNS:`{HOST}`
» User Cuota  : `1`
» Limit IP    : `3`
» Port DNS    : `443, 53`
» port TLS    : `443`
» Port NTLS   : `80`
» NetWork     : `(WS) or (gRPC)`
» User ID     : `{uuid}`
» Path Vless  : `(/multi path)/vless `
» Path Dynamic: `http://Google.com/vless `
» Pub Key     : `{PUB}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS   :
`{x[0]}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link NTLS  :
`{x[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link GRPC  :
`{x[2].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Expira En : `{exp} Minutos`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vless_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" 𝗧𝗥𝗜𝗔𝗟 𝗩𝗟𝗘𝗦𝗦 ","temporal-vless")],
[Button.inline(" 𝗖𝗥𝗘𝗔𝗥 𝗩𝗟𝗘𝗦𝗦 ","crear-vless"),
Button.inline(" 𝗖𝗥𝗘𝗔𝗥 𝗩𝗟𝗘𝗦𝗦 𝗜𝗗","id-vless")],
[Button.inline(" 𝗖𝗛𝗘𝗖𝗞 𝗩𝗟𝗘𝗦𝗦 ","checar-vless"),
Button.inline(" 𝗕𝗢𝗥𝗥𝗔𝗥 𝗩𝗟𝗘𝗦𝗦 ","borrar-vless")],
[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━
**🔹🆅🅻🅴🆂🆂 🅼🅰🅽🅰🅶🅴🆁🔹
━━━━━━━━━━━━━━━━━━━
**🔰 » 𝕊𝕖𝕣𝕧𝕚𝕔𝕖: `VLESS`
**🔰 » 𝔻𝕠𝕞𝕚𝕟𝕚𝕠/𝕀ℙ: `{DOMAIN}`
**🔰 » 𝕀𝕊ℙ: `{z["isp"]}`
**🔰 » ℂ𝕠𝕦𝕟𝕥𝕣𝕪: `{z["country"]}`
━━━━━━━━━━━━━━━━━━━
**🅲🆁🅴🅰🅳🅾🆁 🅑🅨 🅙🅔🅡🅡🅨™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)
