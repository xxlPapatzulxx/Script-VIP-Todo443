from kyt import *

@bot.on(events.CallbackQuery(data=b'normal'))
async def keys(event):
    async def keys_(event):
        cmd = f'bash add-ip'
        await event.edit("`Procesando Informacion al Servidor...`")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        subprocess.check_output(cmd, shell=True)
        await event.edit(f"""
» ᴋᴇʏ ᴄʀᴇᴀᴅᴀ ᴄᴏɴ ᴇxɪᴛᴏ
━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™   
    🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'normal2'))
async def keys2(event):
    async def keys2_(event):
        cmd = f'bash add-ip2'
        await event.edit("`Procesando Informacion al Servidor...`")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        subprocess.check_output(cmd, shell=True)
        await event.edit(f"""
» ᴋᴇʏ ᴄʀᴇᴀᴅᴀ ᴄᴏɴ ᴇxɪᴛᴏ
━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™   
    🤖@Jerry_SBG  
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys2_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'normal3'))
async def keys3(event):
    async def keys3_(event):
        cmd = f'bash add-ip3'
        await event.edit("`Procesando Informacion al Servidor...`")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        subprocess.check_output(cmd, shell=True)
        await event.edit(f"""
» ᴋᴇʏ ᴄʀᴇᴀᴅᴀ ᴄᴏɴ ᴇxɪᴛᴏ
━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™   
    🤖@Jerry_SBG  
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys3_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'vip'))
async def vip(event):
    async def vip_(event):
        cmd = f'bash add-ip4'
        await event.edit("`Procesando Informacion al Servidor...`")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        subprocess.check_output(cmd, shell=True)
        await event.edit(f"""
» ᴋᴇʏ ᴄʀᴇᴀᴅᴀ ᴄᴏɴ ᴇxɪᴛᴏ
━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™   
    🤖@Jerry_SBG  
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vip_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'registrasi'))
async def vless(event):
    async def vless_(event):

        iss = f" curl https://raw.githubusercontent.com/JerrySBG/permission/main/ip | grep $MYIP | awk '{print $8}"
        isss= subprocess.check_output(iss, shell=True).decode("ascii") 

        inline = [
[Button.inline(" 𝓒𝓡𝓔𝓐𝓡 𝓚𝓔𝓨 7 𝓓𝓘𝓐𝓢","normal")],
[Button.inline(" 𝓒𝓡𝓔𝓐𝓡 𝓚𝓔𝓨 15 𝓓𝓘𝓐𝓢","normal2")],
[Button.inline(" 𝓒𝓡𝓔𝓐𝓡 𝓚𝓔𝓨 30 𝓓𝓘𝓐𝓢","normal3")],
[Button.inline(" 𝓕𝓔𝓒𝓗𝓐 𝓥𝓔𝓝𝓓𝓔𝓓𝓞𝓡","vip")],
[Button.inline("‹ 𝓡𝓔𝓖𝓡𝓔𝓢𝓐𝓡›","menu")]]
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        name = f" cat /usr/bin/user"
        user = subprocess.check_output(name, shell=True).decode("ascii")
        seller = f" cat /usr/bin/seller"
        user2= subprocess.check_output(seller, shell=True).decode("ascii")
        svf = f" cat /usr/bin/kyt/var.txt | grep -w ADMIN | head -n1 | sed 's/=//g' | sed 's/ADMIN//g'"
        tg= subprocess.check_output(svf, shell=True).decode("ascii")    
        msg = f"""
━━━━━━━━━━━━━━━━━━━
🅿🆁🅴🅼🅸🆄🅼 🅿🅰🅽🅴🅻 🅼🅴🅽🆄
━━━━━━━━━━━━━━━━━━━
**🔰 » ꜱ.ᴏ      : `{namaos.strip().replace('"','')}`
**🔰 » ᴅᴏᴍɪɴɪᴏ : `{DOMAIN}`
**🔰 » ɪᴘ ᴠᴘꜱ  : `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━
**🔰 » ɪᴅ ᴛɢ  : `{tg.strip()}` <<<
**🔰 » ᴠᴇɴᴅᴇᴅᴏʀ : `{user2.strip()}`
━━━━━━━━━━━━━━━━━━━
     ᴀᴄᴄᴇꜱᴏ ᴀʟ ʙᴏᴛ
     𝓑𝔂 𝓙𝓮𝓻𝓻𝔂™   
    🤖@Jerry_SBG     
━━━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vless_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
