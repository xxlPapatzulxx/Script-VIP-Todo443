from kyt import *

@bot.on(events.CallbackQuery(data=b'normal'))
async def ganti_ip(event):
    async def ganti_ip_(event):
        chat = event.chat_id  # Definisikan variabel chat di sini
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Ingresa Nombre Vendedor:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text.strip()
    
        await event.edit("Procesando.")
        await event.edit("Procesando..")
        await event.edit("Procesando...")
        await event.edit("Procesando....")
        time.sleep(1)
        await event.edit("`Procesando Informacion IPVPS`")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Espera... Configurando una Key`")

        cmd = f'printf "###\n" "1" "${user_conv}" "${serial}" "${isadmin}" "${exp}" | bash /root/usr/bin/add-ip2 | sleep 2 | exit'
        try:
            subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
            await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await ganti_ip_(event)
    else:
        await event.answer("Acceso Denegado", alert=True)
######################################################################################################################################
@bot.on(events.CallbackQuery(data=b'vip'))
async def ganti_ip(event):
    async def create_key(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Nombre de Usuario:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Escoge una Opcion para ADMIN GENERADOR KEYS**",buttons=[
            [Button.inline("CON ACCESO KEY ","ON"),
            Button.inline(" SIN ACCESO KEY ","OFF")]])

        await event.edit("Procesando.")
        await event.edit("Procesando..")
        await event.edit("Procesando...")
        await event.edit("Procesando....")
        time.sleep(1)
        await event.edit("`Procesando Informacion IPVPS`")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Espera... Configurando una Cuenta`")

        cmd = f'printf "###" "${ressel}" "${serial}" "${isadmin}" "${exp}" |  bash /root/usr/bin/add-ip2'
        try:
            subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**🍀 CREADOR DE KEY 🍀**
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**🚦 NOMBRE AUTHOR : {user}**
**🚦 KEY SCRIPT    : {serial}**
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_key(event)
    else:
        await event.answer("Acceso Denegado", alert=True)
######################################################################################################################################
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def vless(event):
    async def vless_(event):
        inline = [
[Button.inline(" CREAR KEY FREE","normal"),
Button.inline(" CREAR KEY CUSTOM ","vip")],
[Button.inline("‹ REGRESAR›","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━
**🐾🕊️ KEY MANAGER 🕊️🐾
━━━━━━━━━━━━━━━━━━━
**🔰 » Service: `KEYS`
**🔰 » Hostname/IP: `{DOMAIN}`
**🔰 » REGION: `{z["region"]}`
**🔰 » Country: `{z["country"]}`
━━━━━━━━━━━━━━━━━━━
**Creador By Jerry™
━━━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vless_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
