from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline("𝗣𝗔𝗡𝗘𝗟 𝗖𝗥𝗘𝗔𝗥 𝗖𝗨𝗘𝗡𝗧𝗔𝗦","menu")],
[Button.url("𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠","https://t.me/Jerry_SBG"),
Button.url("𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣","https://wa.me/+529241293310")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Acceso Denegado", alert=True)
		except:
			await event.reply("Acceso Denegado")
	elif val == "true":
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipinfo.io/ip"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
━━━━━━━━━━━━━━━━━━━
**🔹🅿🆁🅴🅼🅸🆄🅼 🅿🅰🅽🅴🅻 🅼🅴🅽🆄🔹
━━━━━━━━━━━━━━━━━━━
**🔰 » 𝕊.𝕆     : `{namaos.strip().replace('"','')}`
**🔰 » ℂ𝕀𝕌𝔻𝔸𝔻   : `{city.strip()}`
**🔰 » 𝔻𝕆𝕄𝕀ℕ𝕀𝕆 : `{DOMAIN}`
**🔰 » 𝕀ℙ 𝕍ℙ𝕊 : `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━
**🅲🆁🅴🅰🅳🅾🆁 🅑🅨 🅙🅔🅡🅡🅨™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
