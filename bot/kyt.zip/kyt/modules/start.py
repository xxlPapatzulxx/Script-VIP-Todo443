from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline("PANEL GENERADOR KEY","menu")],
[Button.url("TELEGRAM","https://t.me/Jerry_SBG"),
Button.url("WHATSAP","https://wa.me/+529241293310")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Acceso Denegado", alert=True)
		except:
			await event.reply("Acceso Denegado")
	elif val == "true":
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		name = f" cat /usr/bin/user"
		user = subprocess.check_output(name, shell=True).decode("ascii")
		msg = f"""
━━━━━━━━━━━━━━━━━━━
**🐾🕊️ PREMIUM PANEL MENU 🕊️🐾
━━━━━━━━━━━━━━━━━━━
**🔰 » DOMINIO : `{DOMAIN}`
**🔰 » IP VPS  : `{ipsaya.strip()}`
**🔰 » CIUDAD  : `{z["country"]}`
**🔰 » VENDEDOR : `{user.strip()}`
━━━━━━━━━━━━━━━━━━━
**Creador By Jerry™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
