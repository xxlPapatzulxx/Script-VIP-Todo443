from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline("𝐂𝐑𝐄𝐀𝐑 𝐂𝐔𝐄𝐍𝐓𝐀𝐒","menu")],
[Button.url("𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌 𝐀𝐃𝐌𝐈𝐍","https://t.me/Jerry_SBG"),
Button.url("𝐂𝐎𝐌𝐏𝐑𝐀𝐑 𝐒𝐂𝐑𝐈𝐏𝐓","https://t.me/Jerry_SBG")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎", alert=True)
		except:
			await event.reply("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎")
	elif val == "true":
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
**✧◇━━━━━━━━━━━━━━━◇✧**
**🔥 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 🔥**
**✧◇━━━━━━━━━━━━━━━◇✧**

**» ℍ𝕆𝕃𝔸 {sender.first_name} **

✨ **» 𝐒.𝐎     :** `{namaos.strip().replace('"','')}`
✨ **» 𝐂𝐈𝐔𝐃𝐀𝐃  :** `{city.strip()}`
✨ **» 𝐃𝐎𝐌𝐈𝐍𝐈𝐎 :** `{DOMAIN}`
✨ **» 𝐈𝐏 𝐕𝐏𝐒   :** `{ipsaya.strip()}`
🤖 **» @𝐉𝐞𝐫𝐫𝐲_𝐒𝐁𝐆**
**✧◇━━━━━━━━━━━━━━━◇✧**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)



