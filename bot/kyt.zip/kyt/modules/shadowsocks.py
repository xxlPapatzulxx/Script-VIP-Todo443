from kyt import *

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
	async def create_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ᴜꜱᴜᴀʀɪᴏ:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**ᴄᴜᴏᴛᴀ:**",buttons=[
[Button.inline(" 1 ɢʙ ","1"),
Button.inline(" 15 ɢʙ ","15")],
[Button.inline(" 150 ɢʙ ","150"),
Button.inline(" ɪʟɪᴍɪᴛᴀᴅᴏ ","3000")]])
			pw = pw.wait_event(events.CallbackQuery)
			pw = (await pw).data.decode("ascii")
		async with bot.conversation(chat) as exp:
			await event.respond("**ᴇꜱᴄᴏɢᴇʀ ᴅɪᴀꜱ ᴅᴇ ᴇxᴘɪʀᴀᴄɪóɴ**",buttons=[
[Button.inline(" 7 ᴅɪᴀꜱ ","7"),
Button.inline(" 15 ᴅɪᴀꜱ ","15")],
[Button.inline(" 30 ᴅɪᴀꜱ ","30"),
Button.inline(" 60 ᴅɪᴀꜱ ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴜɴᴀ ᴄᴜᴇɴᴛᴀ`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addss-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 𝕐𝕒 𝔼𝕩𝕚𝕤𝕥𝕖**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🆂🅷🅳🆆🆂🅲🆂🅺 🅰🅲🅲🅾🆄🅽🆃
◇━━━━━━━━━━━━━━━━━◇
» Usuario     : `{user}`
» Host Server : `{DOMAIN}`
» Host XrayDNS: `{HOST}`
» User Quota  : `Unlimited`
» Pub Key     : `{PUB}`
» Port TLS    : `443`
» Port GRPC   : `443`
» Port DNS    : `443, 53`
» Password    : `{uuid}`
» Cipers      : `aes-128-gcm`
» NetWork     : `(WS) or (gRPC)`
» Path        : `(/multi path)/ss-ws`
» ServiceName : `ss-grpc`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS    :
`{x[0]}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link gRPC   :
`{x[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link JSON  : `https://${DOMAIN}:81/ss-{user}.txt`
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El: `{later}`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_shadowsocks_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
	async def cek_shadowsocks_(event):
		cmd = 'bot-cek-ss'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
Usuarios Shadowsocks Registrados
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
""",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_shadowsocks_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
	async def delete_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ᴜꜱᴜᴀʀɪᴏ:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-delss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 ℕ𝕠 𝔼𝕟𝕔𝕠𝕟𝕥𝕣𝕒𝕕𝕠**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			msg = f"""**𝔹𝕠𝕣𝕣𝕒𝕕𝕠 𝔼𝕩𝕚𝕥𝕠𝕤𝕒𝕞𝕖𝕟𝕥𝕖**"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_shadowsocks_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
	async def trial_shadowsocks_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**ᴇꜱᴄᴏɢᴇʀ ᴍɪɴᴜᴛᴏꜱ ᴅᴇ ᴇxᴘɪʀᴀᴄɪóɴ**",buttons=[
[Button.inline(" 10 ᴍɪɴᴜᴛᴏꜱ ","10"),
Button.inline(" 15 ᴍɪɴᴜᴛᴏꜱ ","15")],
[Button.inline(" 30 ᴍɪɴᴜᴛᴏꜱ ","30"),
Button.inline(" 60 ᴍɪɴᴜᴛᴏꜱ ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞.")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`🅟🅡🅞🅒🅔🅢🅐🅝🅓🅞... 100%\n█████████████████████████ `")
		time.sleep(0)
		await event.edit("`ᴇꜱᴘᴇʀᴀ... ᴄᴏɴꜰɪɢᴜʀᴀɴᴅᴏ ᴜɴᴀ ᴄᴜᴇɴᴛᴀ`")
		cmd = f'printf "%s\n" "{exp}" | bot-trialss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**𝕌𝕤𝕦𝕒𝕣𝕚𝕠 𝕐𝕒 𝔼𝕩𝕚𝕤𝕥𝕖**",buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
◇━━━━━━━━━━━━━━━━━◇
🆂🅷🅳🆆🆂🅲🆂🅺 🅰🅲🅲🅾🆄🅽🆃
◇━━━━━━━━━━━━━━━━━◇
» Usuario     : `{remarks}`
» Host Server : `{DOMAIN}`
» Host XrayDNS: `{HOST}`
» User Cuota  : `Unlimited`
» Pub Key     : `{PUB}`
» Port TLS    : `443`
» Port GRPC   : `443`
» Port DNS    : `443, 53`
» Password    : `{uuid}`
» Cipers      : `aes-128-gcm`
» NetWork     : `(WS) or (gRPC)`
» Path        : `(/multi path)/ss-ws`
» ServiceName : `ss-grpc`
◇━━━━━━━━━━━━━━━━━━━◇
» Link TLS   :
`{x[0]}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link gRPC  :
`{x[1].replace(" ","")}`
◇━━━━━━━━━━━━━━━━━━━◇
» Link JSON  : `https://${DOMAIN}:81/ss-{remarks}.txt`
◇━━━━━━━━━━━━━━━━━━━◇
» Expira El : `{exp} Minutes`
◇━━━━━━━━━━━━━━━━━◇
Creador By Jerry™
🤖@Jerry_SBG
◇━━━━━━━━━━━━━━━━━◇
"""
			await event.respond(msg,buttons=[[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_shadowsocks_(event)
	else:
		await event.answer("𝐀𝐜𝐜𝐞𝐬𝐨 𝐃𝐞𝐧𝐞𝐠𝐚𝐝𝐨",alert=True)

@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
	async def shadowsocks_(event):
		inline = [
[Button.inline(" 𝗧𝗥𝗜𝗔𝗟 𝗦𝗛𝗗𝗪𝗦𝗖𝗦𝗞 ","trial-shadowsocks"),
Button.inline(" 𝗖𝗥𝗘𝗔𝗥 𝗦𝗛𝗗𝗪𝗦𝗖𝗦𝗞 ","create-shadowsocks")],
[Button.inline(" 𝗖𝗛𝗘𝗖𝗔𝗥 𝗦𝗛𝗗𝗪𝗦𝗖𝗦𝗞 ","cek-shadowsocks"),
Button.inline(" 𝗕𝗢𝗥𝗥𝗔𝗥 𝗦𝗛𝗗𝗪𝗦𝗖𝗦𝗞 ","delete-shadowsocks")],
[Button.inline("‹ 𝗥𝗘𝗚𝗥𝗘𝗦𝗔𝗥 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━
**🔹🆂🅷🅳🆆🆂🅺 🅼🅰🅽🅰🅶🅴🆁🔹
━━━━━━━━━━━━━━━━━━━
**🔰 » 𝕊𝕖𝕣𝕧𝕚𝕔𝕖: `SHADOWSOCKS`
**🔰 » 𝔻𝕠𝕞𝕚𝕟𝕚𝕠/𝕀ℙ: `{DOMAIN}`
**🔰 » 𝕀𝕊ℙ: `{z["isp"]}`
**🔰 » ℂ𝕠𝕦𝕟𝕥𝕣𝕪: `{z["country"]}`
━━━━━━━━━━━━━━━━━━━
**🅲🆁🅴🅰🅳🅾🆁 🅑🅨 🅙🅔🅡🅡🅨™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await shadowsocks_(event)
	else:
		await event.answer("Access Denied",alert=True)
