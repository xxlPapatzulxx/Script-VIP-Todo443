from kyt import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.edit(f"""
**✨ ɴᴏᴍʙʀᴇ ᴍɪxᴛᴏ, ʟᴇᴛʀᴀꜱ ᴍᴀʏÚꜱᴄᴜʟᴀꜱ ʏ ɴÚᴍᴇʀᴏꜱ**
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ꜱɪɴ ᴅᴏʙʟᴇ ɴᴏᴍʙʀᴇ**
**✨ Bot : @Jerry_SBG**

**✨ 𝐍𝐎𝐌𝐁𝐑𝐄 𝐃𝐄 𝐂𝐔𝐄𝐍𝐓𝐀  :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**✨ 𝐄𝐒𝐂𝐑𝐈𝐁𝐀 𝐋𝐀 𝐂𝐎𝐍𝐓𝐑𝐀𝐒𝐄Ñ𝐀 :**
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**✨ 𝐄𝐒𝐂𝐑𝐈𝐁𝐀 𝐄𝐗𝐏 (𝐃𝐈𝐀𝐒) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**✨ 𝐋𝐈𝐌𝐈𝐓𝐄 𝐈𝐍𝐈𝐂𝐈𝐎 𝐃𝐄 𝐒𝐈𝐒𝐈𝐎𝐍 :**
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "1" "{user}" "{pw}" "{exp}" "{pw2}" | bash m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐂𝐑𝐄𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐋𝐈𝐒𝐓𝐀 𝐄𝐋𝐈𝐌𝐈𝐍𝐀𝐑 𝐔𝐒𝐔𝐀𝐑𝐈𝐎**
{z}
**✨ 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐍𝐔𝐌𝐄𝐑𝐎 𝐀 𝐄𝐋𝐈𝐌𝐈𝐍𝐀𝐑 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | bash m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐁𝐎𝐑𝐑𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'limit-ssh'))
async def limit_ssh(event):
	async def limit_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐂𝐀𝐌𝐁𝐈𝐀𝐑 𝐋𝐈𝐌𝐈𝐓𝐄 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎**
{z}
**✨ 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**✨ 𝐄𝐬𝐜𝐫𝐢𝐛𝐚 𝐍𝐮𝐞𝐯𝐨 𝐥í𝐦𝐢𝐭𝐞 𝐝𝐞 𝐈𝐏 :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "7" "{user}" "{exp}" | bash m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐌𝐈𝐓𝐄 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
**✨ 𝐈𝐍𝐆𝐑𝐄𝐒𝐀 𝐋𝐀 𝐄𝐗𝐏 (𝐌𝐈𝐍𝐔𝐓𝐎𝐒) :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | bash m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐂𝐑𝐄𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
@bot.on(events.CallbackQuery(data=b'cek-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇꜱᴀɴᴅᴏ... 100%\n█████████████████████████ `")
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		
		await event.edit(f"""
**✨ 𝐒𝐒𝐇 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒 𝐎𝐍𝐋𝐈𝐍𝐄**
{z}
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)


@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
	async def renew_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐑𝐄𝐍𝐎𝐕𝐀𝐂𝐈𝐎𝐍 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒**
{z}
**✨ 𝐈𝐍𝐆𝐑𝐄𝐒𝐀 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**✨ 𝐍𝐔𝐄𝐕𝐀 𝐄𝐗𝐏 (𝐃𝐈𝐀𝐒) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | bash m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐑𝐄𝐍𝐎𝐕𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/sshx/listlock | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒 𝐌𝐔𝐋𝐓𝐈 𝐋𝐎𝐆𝐈𝐍**
{z}
**✨ 𝐈𝐍𝐆𝐑𝐄𝐒𝐀 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | bash m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐃𝐄𝐒𝐁𝐋𝐎𝐐𝐔𝐄𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'akun-ssh'))
async def akun_ssh(event):
	async def akun_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐂𝐎𝐍𝐅𝐈𝐆 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒**
{z}
**✨ 𝐈𝐍𝐆𝐑𝐄𝐒𝐀 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | bash m-sshovpn | sleep 2 | exit'
			z = subprocess.check_output(cmd, shell=True).decode("ascii")
			await event.respond(f"""
{z}
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" 𝐓𝐑𝐈𝐀𝐋 ","trial-ssh"),
Button.inline(" 𝐂𝐑𝐄𝐀𝐑 ","create-ssh"),
Button.inline(" 𝐀𝐂𝐓𝐈𝐕𝐎𝐒 ","cek-ssh")],
[Button.inline(" 𝐁𝐎𝐑𝐑𝐀𝐑 ","delete-ssh"),
Button.inline(" 𝐔𝐍𝐋𝐎𝐂𝐊 ","login-ssh"),
Button.inline(" 𝐋𝐈𝐌𝐈𝐓𝐄 ","limit-ssh")],
[Button.inline(" 𝐑𝐄𝐍𝐎𝐕𝐀𝐑","renew-ssh"),
Button.inline("𝐂𝐎𝐍𝐅𝐈𝐆 ","akun-ssh"),
Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		msg = f"""
**✧◇━━━━━━━━━━━━━━━◇✧**
      **🔥 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 🔥**
**✧◇━━━━━━━━━━━━━━━◇✧**
✨ **» 𝐏𝐑𝐎𝐓𝐎𝐂𝐎𝐋𝐎:** `𝕊𝕊ℍ`
✨ **» 𝐓𝐎𝐓𝐀𝐋 𝐂𝐔𝐄𝐍𝐓𝐀𝐒  :** `{ssh.strip()}` __CUENTAS__
✨ **» 𝐃𝐎𝐌𝐈𝐍𝐈𝐎:** `{DOMAIN}`
✨ **» 𝐂𝐈𝐔𝐃𝐀𝐃:** `{z["city"]}`
✨ **» 𝐏𝐀𝐈𝐒:** `{z["country"]}`
🤖 **» @𝐉𝐞𝐫𝐫𝐲_𝐒𝐁𝐆**
**✧◇━━━━━━━━━━━━━━━◇✧**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
