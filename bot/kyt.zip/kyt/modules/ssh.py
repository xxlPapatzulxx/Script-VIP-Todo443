from kyt import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.edit(f"""
**✨ No Espacios**
**✨ No Dobles Nombres**
**✨ Admin : @Jerry_SBG**

**✨ Nombre de Usuario  :**
/cancel Volver al MENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**✨ INGRESA UNA CONTRASEÑA :**
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**✨ INGRESA LA EXPIRACION (DIAS) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**✨ INGRESA LIMITE DE IP :**
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "1" "{user}" "{pw}" "{exp}" "{pw2}" | bash /usr/local/sbin/m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» CREADO CON EXITO**
**» LISTO**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LISTA BORRADO DE USUARIO**
{z}
**✨ ESCRIBA EL NUMERO :**
/cancel Volver al MENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | bash /usr/local/sbin/m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» BORRADO CON EXITO**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'limit-ssh'))
async def limit_ssh(event):
	async def limit_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ CAMBIAR LIMITE DE USUARIO**
{z}
**✨ ESCRIBA EL NUMERO :**
/cancel Volver al MENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**✨ Nuevo límite de IP de Inicio de Sesion :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "7" "{user}" "{exp}" | bash /usr/local/sbin/m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» CON EXITO**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
**✨ INGRESA LOS MINUTOS (Minutos) :**
/cancel Volver al MENU
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | bash /usr/local/sbin/m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» CON EXITO**
**» LISTO**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
@bot.on(events.CallbackQuery(data=b'cek-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		time.sleep(0)
		await event.edit("`PROCESANDO... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`PROCESANDO... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`PROCESANDO... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit("`PROCESANDO... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`PROCESANDO... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`PROCESANDO... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`PROCESANDO... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`PROCESANDO... 100%\n█████████████████████████ `")
		await event.edit(f"""
** SSH USUARIOS ONLINE**
{z}
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)


@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
	async def renew_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST RENEW USER**
{z}
**✨ INGRESA NUMERO :**
/cancel Volver al MENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**✨ NUEVA EXPIRACION (día) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | bash /usr/local/sbin/m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» CON EXITO**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/sshx/listlock | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ LIST MULTI LOGIN USER**
{z}
**✨ESCRIBA UN NUMERO :**
/cancel Volver al MENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | bash /usr/local/sbin/m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» DESBLOQUEADO CON EXITO**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'akun-ssh'))
async def akun_ssh(event):
	async def akun_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ CEK CONFIG USER**
{z}
**✨ INGRESA UN NUMERO :**
/cancel Volver al MENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | bash /usr/local/sbin/m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» VERIFICACION DE CUENTA EXITOSA**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" 𝐓𝐄𝐌𝐏𝐎𝐑𝐀𝐋 ","trial-ssh"),
Button.inline(" 𝐂𝐑𝐄𝐀𝐑 ","create-ssh"),
Button.inline(" 𝐋𝐎𝐆𝐈𝐍 ","cek-ssh")],
[Button.inline(" 𝐁𝐎𝐑𝐑𝐀𝐑 ","delete-ssh"),
Button.inline(" 𝐔𝐍𝐋𝐎𝐂𝐊 ","login-ssh"),
Button.inline(" 𝐋𝐈𝐌𝐈𝐓𝐄 ","limit-ssh")],
[Button.inline(" 𝐑𝐄𝐍𝐎𝐕𝐀𝐑","renew-ssh"),
Button.inline("𝐂𝐔𝐄𝐍𝐓𝐀𝐒 ","akun-ssh"),
Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		msg = f"""
**✧◇━━━━━━━━━━━━━━━◇✧**
  **🔥 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 𝐒𝐒𝐇 🔥**
**✧◇━━━━━━━━━━━━━━━◇✧**
✨ **» 𝐒𝐞𝐫𝐯𝐢𝐜𝐞:** `𝐒𝐒𝐇`
✨ **» 𝐓𝐎𝐓𝐀𝐋 𝐂𝐔𝐄𝐍𝐓𝐀𝐒  :** `{ssh.strip()}` __account__
✨ **» 𝐇𝐎𝐒𝐓:** `{DOMAIN}`
✨ **» 𝐈𝐒𝐏:** `{z["isp"]}`
✨ **» 𝐂𝐈𝐔𝐃𝐀𝐃:** `{z["country"]}`
🤖 **» @𝐉𝐞𝐫𝐫𝐲_𝐒𝐁𝐆**
**✧◇━━━━━━━━━━━━━━━◇✧**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
