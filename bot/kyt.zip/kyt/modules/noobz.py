from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-noobz'))
async def delete_noobz(event):
	async def delete_noobz_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^##' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐋𝐈𝐒𝐓𝐀 𝐄𝐋𝐈𝐌𝐈𝐍𝐀𝐑 𝐔𝐒𝐔𝐀𝐑𝐈𝐎**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | bash m-ss | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_noobz_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-noobz'))
async def renew_noobz(event):
	async def renew_noobz_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^##' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐑𝐄𝐍𝐎𝐕𝐀𝐂𝐈𝐎𝐍 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 𝐍𝐔𝐄𝐕𝐀 𝐄𝐗𝐏 (𝐃𝐈𝐀𝐒) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | bash m-ss | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_noobz_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)

#CekConfig
@bot.on(events.CallbackQuery(data=b'akun7-noobz'))
async def akun_noobz(event):
	async def akun_noobz_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^##' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**✨ 𝐂𝐎𝐍𝐅𝐈𝐆 𝐃𝐄 𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒**
{z}
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐄 𝐄𝐋 𝐍𝐔𝐌𝐄𝐑𝐎 :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | bash m-ss | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_noobz_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
#CRATE noobz
@bot.on(events.CallbackQuery(data=b'create7-noobz'))
async def create_noobz(event):
	async def create_noobz_(event):
		async with bot.conversation(chat) as user:
			await event.edit(f"""
**✨ ɴᴏᴍʙʀᴇ ᴍɪxᴛᴏ, ʟᴇᴛʀᴀꜱ ᴍᴀʏÚꜱᴄᴜʟᴀꜱ ʏ ɴÚᴍᴇʀᴏꜱ**
**✨ ɴᴏ ᴇꜱᴘᴀᴄɪᴏꜱ**
**✨ ꜱɪɴ ᴅᴏʙʟᴇ ɴᴏᴍʙʀᴇ**
**✨ Bot : @Jerry_SBG**

**👉 𝐍𝐎𝐌𝐁𝐑𝐄 𝐃𝐄 𝐂𝐔𝐄𝐍𝐓𝐀  :**
/cancel ᴠᴏʟᴠᴇʀ ᴀʟ ᴍᴇɴᴜ
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» 𝐂𝐀𝐍𝐂𝐄𝐋𝐀𝐃𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**👉 𝐄𝐒𝐂𝐑𝐈𝐁𝐀 𝐄𝐗𝐏 (𝐃𝐈𝐀𝐒) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "1" "{user}" "{exp}" | bash m-ss | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» 𝐂𝐑𝐄𝐀𝐃𝐎 𝐂𝐎𝐍 𝐄𝐗𝐈𝐓𝐎**
**» 𝐋𝐈𝐒𝐓𝐎**
""",buttons=[[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_noobz_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
		
@bot.on(events.CallbackQuery(data=b'noobz'))
async def noobz(event):
	async def noobz_(event):
		inline = [
[Button.inline(" 𝐂𝐑𝐄𝐀𝐑 ","create7-noobz"),
Button.inline(" 𝐁𝐎𝐑𝐑𝐀𝐑 ","delete7-noobz")],
[Button.inline(" 𝐑𝐄𝐍𝐎𝐕𝐀𝐑","renew7-noobz"),
Button.inline(" 𝐂𝐎𝐍𝐅𝐈𝐆 ","akun7-noobz")],
[Button.inline("‹ 𝐑𝐄𝐆𝐑𝐄𝐒𝐀𝐑 ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vm = f' cat /etc/xray/config.json | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		msg = f"""
**✧◇━━━━━━━━━━━━━━◇✧**
      **🔥 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔 🔥**
**✧◇━━━━━━━━━━━━━━◇✧**
✨ **» 𝐏𝐑𝐎𝐓𝐎𝐂𝐎𝐋𝐎:** `𝕊ℍ𝔸𝔻𝕆𝕎𝕊𝕆ℂ𝕂`
✨ **» 𝐓𝐎𝐓𝐀𝐋 𝐂𝐔𝐄𝐍𝐓𝐀𝐒  :** `{vms.strip()}` __CUENTAS__
✨ **» 𝐃𝐎𝐌𝐈𝐍𝐈𝐎:** `{DOMAIN}`
✨ **» 𝐂𝐈𝐔𝐃𝐀𝐃:** `{z["city"]}`
✨ **» 𝐏𝐀𝐈𝐒:** `{z["country"]}`
🤖 **» @𝐉𝐞𝐫𝐫𝐲_𝐒𝐁𝐆**
**✧◇━━━━━━━━━━━━━━◇✧**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await noobz_(event)
	else:
		await event.answer("𝐀𝐂𝐂𝐄𝐒𝐎 𝐃𝐄𝐍𝐄𝐆𝐀𝐃𝐎",alert=True)
