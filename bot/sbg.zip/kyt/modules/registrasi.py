from kyt import *

@bot.on(events.CallbackQuery(data=b'normal'))
async def keys(event):
    async def keys_(event):
        await event.edit("Procesando....")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Espera... Configurando una Key`")
        ox2 = "VIP"
        ox = requests.get(f"https://ipv4.icanhazip.com").text.strip()
        bz = f" curl -sS https://raw.githubusercontent.com/JerrySBG/permission/main/ip | grep '{ox}' | cut -d ' ' -f7 "
        bo = subprocess.check_output(bz, shell=True).decode("ascii").strip()
        if not ox2 != bo:
        cmd = f'bash /root/usr/bin/add-ip'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.edit(f"""
» CREADA KEYS 7 DIAS
━━━━━━━━━━━━━━━━━
Creador By Jerry™
━━━━━━━━━━━━━━━━━
Compra Tu Acceso Al BOT
🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'normal2'))
async def keys2(event):
    async def keys2_(event):
        await event.edit("Procesando....")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Espera... Configurando una Key`")
        ox2 = "VIP"
        ox = requests.get(f"https://ipv4.icanhazip.com").text.strip()
        bz = f" curl -sS https://raw.githubusercontent.com/JerrySBG/permission/main/ip | grep '{ox}' | cut -d ' ' -f7 "
        bo = subprocess.check_output(bz, shell=True).decode("ascii").strip()
        if not ox2 != bo:
        cmd = f'bash /root/usr/bin/add-ip2'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.edit(f"""
» CREADA KEYS 7 DIAS
━━━━━━━━━━━━━━━━━
Creador By Jerry™
━━━━━━━━━━━━━━━━━
Compra Tu Acceso Al BOT
🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys2_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
######################################################################################################################################

@bot.on(events.CallbackQuery(data=b'normal3'))
async def keys3(event):
    async def keys3_(event):
        await event.edit("Procesando....")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Espera... Configurando una Key`")
        ox2 = "VIP"
        ox = requests.get(f"https://ipv4.icanhazip.com").text.strip()
        bz = f" curl -sS https://raw.githubusercontent.com/JerrySBG/permission/main/ip | grep '{ox}' | cut -d ' ' -f7 "
        bo = subprocess.check_output(bz, shell=True).decode("ascii").strip()
        if not ox2 != bo:
        cmd = f'bash /root/usr/bin/add-ip3'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.edit(f"""
» CREADA KEYS 7 DIAS
━━━━━━━━━━━━━━━━━
Creador By Jerry™
━━━━━━━━━━━━━━━━━
Compra Tu Acceso Al BOT
🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await keys3_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
######################################################################################################################################
@bot.on(events.CallbackQuery(data=b'vip'))
async def vip(event):
    async def vip_(event):
        await event.edit("Procesando....")
        time.sleep(1)
        await event.edit("`Procesando... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 36%\n████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Procesando... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Procesando... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Espera... Configurando una Key`")
        ox2 = "VIP"
        ox = requests.get(f"https://ipv4.icanhazip.com").text.strip()
        bz = f" curl -sS https://raw.githubusercontent.com/JerrySBG/permission/main/ip | grep '{ox}' | cut -d ' ' -f7 "
        bo = subprocess.check_output(bz, shell=True).decode("ascii").strip()
        if not ox2 != bo:
        cmd = f'bash /root/usr/bin/add-ip4'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.edit(f"""
» CREADA KEYS 7 DIAS
━━━━━━━━━━━━━━━━━
Creador By Jerry™
━━━━━━━━━━━━━━━━━
Compra Tu Acceso Al BOT
🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ REGRESAR ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vip_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
######################################################################################################################################
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def vless(event):
    async def vless_(event):
        inline = [
[Button.inline(" CREAR KEY 7 DIAS","normal"),
Button.inline(" CREAR KEY 15 DIAS ","normal2")],
[Button.inline(" CREAR KEY 30 DIAS","normal3"),
Button.inline(" CREAR KEY FECHA VENDEDOR ","vip")],
[Button.inline("‹ REGRESAR›","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━
**🐾🕊️ KEY MANAGER 🕊️🐾
━━━━━━━━━━━━━━━━━━━
**🔰 » Service: `KEYS`
**🔰 » Hostname/IP: `{DOMAIN}`
**🔰 » ISP: `{z["isp"]}`
**🔰 » Country: `{z["country"]}`
━━━━━━━━━━━━━━━━━━━
**Creador By Jerry™
━━━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vless_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
