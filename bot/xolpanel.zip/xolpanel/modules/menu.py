from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
Button.inline(" CONFIGURACIONES ","setting"),
[Button.inline(" DOMINIOS FREE","domain"),
Button.inline(" GENERADOR KEY ","registrasi")],
[Button.inline(" ‹ REGRESAR › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Acceso Denegado", alert=True)
		except:
			await event.reply("Acceso Denegado")
	elif val == "true":
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		name = f" cat /usr/bin/user"
		user = subprocess.check_output(name, shell=True).decode("ascii")
		
		msg = f"""
━━━━━━━━━━━━━━━━━━━
🐾🕊️ ADMIN PANEL MENU 🕊️🐾
━━━━━━━━━━━━━━━━━━━
**🔰 » DOMAIN : `{DOMAIN}`
**🔰 » IP VPS : `{ipsaya.strip()}`
**🔰 » VENDEDOR : `{user.strip()}`
━━━━━━━━━━━━━━━━━━━
**Creador By Jerry™
**🤖@Jerry_SBG
━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)